"""create admin user

Revision ID: fca26542103b
Revises: 8faf972a3e37
Create Date: 2021-01-04 20:09:02.847167

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, INT, BOOLEAN, TIMESTAMP, LargeBinary


# revision identifiers, used by Alembic.
revision = 'fca26542103b'
down_revision = '8faf972a3e37'
branch_labels = None
depends_on = None

accounts = table('user',
    column('username', String),
    column('password', String),
    column('refresh_token', String),
)

def upgrade():
    op.bulk_insert(accounts,
                   [
                       {'username': 'admin',
                        'password': '$2b$12$zolpFkKvhuvhHE5g7Ph5Te46ccV0y1ueYg3J7g342CakNcnvOGI0O',
                        'refresh_token': None}
                   ])


def downgrade():
    pass
