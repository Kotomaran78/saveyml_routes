"""create history table

Revision ID: 8faf972a3e37
Revises: 4dcda8dd5cfb
Create Date: 2021-01-04 20:07:54.788652

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
from sqlalchemy import Text
from sqlalchemy.dialects import postgresql

revision = '8faf972a3e37'
down_revision = '4dcda8dd5cfb'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('history',
                    sa.Column('id', sa.INTEGER(), server_default=sa.text("nextval('history_id_seq'::regclass)"),
                              autoincrement=True, nullable=False),
                    sa.Column('device', sa.VARCHAR(length=255), autoincrement=False, nullable=True),
                    sa.Column('value', postgresql.JSON(astext_type=Text()), autoincrement=False, nullable=True),
                    sa.Column('created_at', postgresql.TIMESTAMP(timezone=True), server_default=sa.text('now()'),
                              autoincrement=False, nullable=True),
                    sa.Column('read_at', postgresql.TIMESTAMP(timezone=True), autoincrement=False, nullable=True),
                    sa.PrimaryKeyConstraint('id', name='history_pk')
                    )
    op.create_index('history_id_uindex', 'history', ['id'], unique=True)


def downgrade():
    pass
