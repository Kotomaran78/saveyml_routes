"""update slave_id device table

Revision ID: 8e428932ede2
Revises: fca26542103b
Create Date: 2021-01-11 12:31:18.668889

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import String, INTEGER

# revision identifiers, used by Alembic.
revision = '8e428932ede2'
down_revision = 'fca26542103b'
branch_labels = None
depends_on = None


def upgrade():
    op.alter_column('device',
                    'slave_id',
                    existing_type=INTEGER,
                    type_=String,
                    nullable=True
                    )


def downgrade():
    pass
