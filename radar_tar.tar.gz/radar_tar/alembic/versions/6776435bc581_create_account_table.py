"""create account table

Revision ID: 6776435bc581
Revises: 
Create Date: 2021-01-04 20:01:41.615077

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
from sqlalchemy.dialects import postgresql

revision = '6776435bc581'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('user',
                    sa.Column('id', sa.INTEGER(), server_default=sa.text("nextval('user_id_seq'::regclass)"),
                              autoincrement=True, nullable=False),
                    sa.Column('username', sa.VARCHAR(length=255), autoincrement=False, nullable=True),
                    sa.Column('password', postgresql.BYTEA(), autoincrement=False, nullable=True),
                    sa.Column('refresh_token', sa.VARCHAR(length=255), autoincrement=False, nullable=True),
                    sa.PrimaryKeyConstraint('id', name='user_pk')
                    )
    op.create_index('user_id_uindex', 'user', ['id'], unique=True)
    op.create_index('user_username_uindex', 'user', ['username'], unique=True)


def downgrade():
    op.drop_table('user')
