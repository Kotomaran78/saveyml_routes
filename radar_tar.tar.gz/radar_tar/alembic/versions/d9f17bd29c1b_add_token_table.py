"""add token table

Revision ID: d9f17bd29c1b
Revises: da42671c5f6e
Create Date: 2021-02-07 22:22:51.319120

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'd9f17bd29c1b'
down_revision = 'da42671c5f6e'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('access_tokens',
                    sa.Column('id', sa.INTEGER(), server_default=sa.text("nextval('access_tokens_id_seq'::regclass)"),
                              autoincrement=True, nullable=False),
                    sa.Column('token', sa.VARCHAR(length=255), autoincrement=False, nullable=False),
                    sa.Column('user_id', sa.INTEGER(), autoincrement=False, nullable=True),
                    sa.ForeignKeyConstraint(['user_id'], ['user.id'], name='access_tokens_user_id_fk'),
                    sa.PrimaryKeyConstraint('id', name='access_tokens_pk')
                    )
    op.create_index('access_tokens_id_uindex', 'access_tokens', ['id'], unique=True)
    op.create_index('access_tokens_token_uindex', 'access_tokens', ['token'], unique=True)


def downgrade():
    pass
