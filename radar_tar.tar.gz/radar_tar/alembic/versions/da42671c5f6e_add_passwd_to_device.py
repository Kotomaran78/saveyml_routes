"""add passwd to device

Revision ID: da42671c5f6e
Revises: d7d437d7e62e
Create Date: 2021-01-19 19:00:39.156031

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'da42671c5f6e'
down_revision = 'd7d437d7e62e'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        'device',
        sa.Column(
            'password',
            sa.VARCHAR(length=255), autoincrement=False, nullable=True
        )
    )


def downgrade():
    pass
