"""create device table

Revision ID: 4dcda8dd5cfb
Revises: 6776435bc581
Create Date: 2021-01-04 20:07:09.974904

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '4dcda8dd5cfb'
down_revision = '6776435bc581'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('device',
                    sa.Column('id', sa.INTEGER(), server_default=sa.text("nextval('device_id_seq'::regclass)"),
                              autoincrement=True, nullable=False),
                    sa.Column('device', sa.VARCHAR(length=255), autoincrement=False, nullable=True),
                    sa.Column('slave_id', sa.BIGINT(), autoincrement=False, nullable=True),
                    sa.Column('topic', sa.VARCHAR(length=255), autoincrement=False, nullable=True),
                    sa.Column('port', sa.VARCHAR(length=255), autoincrement=False, nullable=True),
                    sa.Column('interval', sa.INTEGER(), autoincrement=False, nullable=True),
                    sa.Column('history', sa.INTEGER(), autoincrement=False, nullable=True),
                    sa.Column('address', sa.VARCHAR(length=255), autoincrement=False, nullable=True),
                    sa.PrimaryKeyConstraint('id', name='device_pk')
                    )
    op.create_index('device_device_port_address_uindex', 'device', ['device', 'port', 'address'], unique=True)
    op.create_index('device_id_uindex', 'device', ['id'], unique=True)
    op.create_index('device_device_port_slave_id_uindex', 'device', ['device', 'port', 'slave_id'], unique=True)


def downgrade():
    op.drop_table('device')
