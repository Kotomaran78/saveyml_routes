"""add registers to device

Revision ID: d7d437d7e62e
Revises: 8e428932ede2
Create Date: 2021-01-19 18:36:47.727502

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import Text
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = 'd7d437d7e62e'
down_revision = '8e428932ede2'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        'device',
        sa.Column(
            'registers',
            postgresql.JSON(
                astext_type=Text()
            ),
            autoincrement=False,
            nullable=True
        )
    )


def downgrade():
    pass