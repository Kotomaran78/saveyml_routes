# import bcrypt
# from sanic.response import json
#
# from project.db.tables import users
#
#
# class ExResponses(Responses):
#     @staticmethod
#     def exception_response(request, exception):
#         exception_message = exception.args
#         if isinstance(exception.args, tuple):
#             exception_message = exception.args[0]
#             if isinstance(exception_message, list):
#                 exception_message = exception_message[0]
#         elif isinstance(exception.args, list):
#             exception_message = exception.args[0][0]
#         return json({
#             'error': exception.__class__.__name__,
#             'message': str(exception_message)
#         }, status=exception.status)
#
#
# class AuthRoutes:
#     def __init__(self, web) -> None:
#         self.__web = web
#         self.__app = web.app
#
#     @property
#     def app(self):
#         return self.__app
#
#     async def authenticate(self, request, *args, **kwargs):
#         data = request.json
#         if 'username' not in data:
#             raise exceptions.AuthenticationFailed("Missing username or password.")
#         if 'password' not in data:
#             raise exceptions.AuthenticationFailed("Missing username or password.")
#
#         username = request.json.get("username", None)
#         password = request.json.get("password", None).encode('utf-8')
#
#         query = users.select().with_only_columns([users.c.id, users.c.password, users.c.username]).where(
#             users.c.username == username)
#         user = await request.app.db.fetch_one(query)
#         if not user:
#             raise exceptions.AuthenticationFailed("User or password is incorrect.")
#
#         to_dict = lambda r: {k: v for k, v in r.items()}
#         user = to_dict(user)
#
#         if user is None or not bcrypt.checkpw(password, user['password']):
#             raise exceptions.AuthenticationFailed("User or password is incorrect.")
#
#         return user
#
#     async def retrieve_user(self, request, payload, *args, **kwargs):
#         to_dict = lambda r: {k: v for k, v in r.items()}
#         result = None
#         if payload:
#             id = payload.get('id', None)
#             if id is not None:
#                 query = users.select().with_only_columns([users.c.id, users.c.username]).where(users.c.id == id)
#                 user = await request.app.db.fetch_one(query)
#                 result = to_dict(user)
#         return result
#
#     async def store_refresh_token(self, request, user_id, refresh_token, *args, **kwargs):
#         user = await request.app.db.execute(
#             users.update().where(users.c.id == user_id).values(refresh_token=refresh_token))
#         return
#
#     async def retrieve_refresh_token(self, request, user_id, *args, **kwargs):
#         query = users.select().with_only_columns([users.c.refresh_token]).where(users.c.id == int(user_id))
#         user = await request.app.db.fetch_one(query)
#         if 'refresh_token' in user:
#             refresh_token = user['refresh_token']
#         else:
#             return False
#         return refresh_token
