from .routes import load_routes
# from .auth import AuthRoutes, ExResponses
from .serial_routes import load_serial
from .device_routes import load_device
from .config_routes import load_config
from .system_routes import load_system
from .tokenAuth import AuthRoutes

from .saveyml_routes import save_data_to_yml