

def load_system(web, app):
    auth = web.auth

    @web.route('/api/ping', methods=['POST'])
    @auth.login_required
    async def handler(request):
        return await app.service.systemService.ping(request.json)

    @web.route('/api/trace', methods=['POST'])
    @auth.login_required
    async def handler(request):
        return await app.service.systemService.trace(request.json)

    @web.route('/api/ntp')
    @auth.login_required
    async def handler(request):
        return await app.service.ntpService.current_ntps(request.json)

    @web.route('/api/ntp', methods=['POST'])
    @auth.login_required
    async def handler(request):
        return await app.service.ntpService.update_ntp(request.json)
