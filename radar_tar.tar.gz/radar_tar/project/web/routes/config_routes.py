from sanic.response import json

def load_config(web, app):
    auth = web.auth
    config = app.service.configService

    @web.route('/api/config/locale')
    async def handler(request):
        return await config.get_locale()

    @web.route('/api/config/locale', methods=['POST'])
    async def handler(request):
        return await config.locale(request)

    @web.route('/api/status')
    @auth.login_required
    async def handler(request):
        return await config.status()

    @web.route('/api/config/network')
    @auth.login_required
    async def handler(request):
        return await config.network(request)

    @web.route('/api/config/network', methods=['POST'])
    @auth.login_required
    async def handler(request):
        return await config.update_network(request)

    @web.route('/api/config/mqtt')
    @auth.login_required
    async def handler(request):
        return await config.mqtt(request)

    @web.route('/api/config/mqtt/main', methods=['POST'])
    @auth.login_required
    async def handler(request):
        await config.update_mqtt(request, 'main')
        return True

    @web.route('/api/config/mqtt/backup', methods=['POST'])
    @auth.login_required
    async def handler(request):
        await config.update_mqtt(request, 'backup')
        return True

    @web.route('/api/config/time')
    @auth.login_required
    async def handler(request):
        return await config.time(request)

    @web.route('/api/config/auth')
    @auth.login_required
    async def handler(request):
        return await config.auth(request)

    @web.route('/api/config/update', methods=['POST'])
    @auth.login_required
    async def handler(request):
        return await config.update(request)

    @web.route('/api/config/reboot', methods=['POST'])
    @auth.login_required
    async def handler(request):
        return await config.reboot(request)

    @web.route('/api/config/reset', methods=['POST'])
    @auth.login_required
    async def handler(request):
        return await config.reset(request)

    @web.route('/api/ssh')
    @auth.login_required
    async def handler(request):
        return await config.ssh_status()

    @web.route('/api/ssh', methods=['POST'])
    @auth.login_required
    async def handler(request):
        return await config.ssh_update(request.json)
