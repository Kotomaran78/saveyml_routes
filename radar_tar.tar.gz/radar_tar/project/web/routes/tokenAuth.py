import os
import bcrypt
import binascii
from sanic_httpauth import HTTPTokenAuth
from sanic_httpauth_compat import get_request
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from itsdangerous import SignatureExpired
from itsdangerous import JSONWebSignatureSerializer
from project.web.errors import AuthenticationFailed, AuthFailed, Unauthorized, UserNotFound
from project.db.tables import users, tokens
from functools import wraps
import asyncio


class AuthRoutes:
    def __init__(self, web):
        self.web = web
        self.auth = HTTPTokenAuth("Bearer")
        self.token_serializer = Serializer(web.app.config['web']['sanic']["SECRET_KEY"], expires_in=1800)
        self.auth.verify_token(self.verify_token)
        self.auth.error_handler(self.error_handler)

    @property
    def db(self):
        return self.web.app.db

    def _generate_refresh_token(self, n=24, *args, **kwargs):
        return str(binascii.hexlify(os.urandom(n)), "utf-8")

    def login_required(self, f):
        return self.auth.login_required(f)

    async def check_token(self, token):
        query = tokens.select().with_only_columns([tokens.c.id, tokens.c.token]).where(tokens.c.token == token)
        t1 = await self.db.fetch_one(query)
        print(t1)
        exist_token = None
        if exist_token:
            return True
        return False

    def verify_token(self, token):
        try:
            user = self.token_serializer.loads(token)
            return True
        except Exception as e:  # noqa: E722
            print(e)
            if isinstance(e, SignatureExpired):
                print(e.payload)
                print(e.date_signed)
                raise Unauthorized(message='Signature expired')
            if isinstance(e, Unauthorized):
                raise e
            return False

    def inject_user(self, f):
        @wraps(f)
        def decorated(*args, **kwargs):
            request = get_request(*args, **kwargs)

            data = self.token_serializer.loads(self.auth.token(request))
            return f(*args, data)
        return decorated

    def token(self, request):
        if not request.ctx.authorization:
            return ""
        return request.ctx.authorization.get("token")

    def error_handler(self, f):
        raise Unauthorized

    def _generate_token(self, user):
        return self.token_serializer.dumps({"id": user['id'], "username": user['username']}).decode("utf-8")

    async def auth_user(self, request):
        data = request.json
        if 'username' not in data:
            raise AuthenticationFailed
        if 'password' not in data:
            raise AuthenticationFailed

        username = request.json.get("username", None)
        password = request.json.get("password", None).encode('utf-8')

        query = users.select().with_only_columns([users.c.id, users.c.password, users.c.username]).where(
            users.c.username == username)
        user = await request.app.db.fetch_one(query)
        if not user:
            raise AuthFailed

        to_dict = lambda r: {k: v for k, v in r.items()}
        user = to_dict(user)

        if user is None or not bcrypt.checkpw(password, user['password']):
            raise AuthFailed

        token = self._generate_token(user)
        refresh_token = self._generate_refresh_token()

        await self.db.execute(users.update().where(users.c.id == user['id']).values(refresh_token=refresh_token))

        query = tokens.select().with_only_columns([tokens.c.id, tokens.c.token]).where(tokens.c.token == token)
        old_token = await self.db.fetch_one(query)
        if old_token is None:
            await self.db.execute(tokens.insert().values(token=token, user_id=user['id']))

        return {'access_token': token, 'refresh_token': refresh_token}

    async def update_token(self, request, user):
        refresh_token = request.json.get('refresh_token')

        if refresh_token is None:
            raise Unauthorized(message='Refresh token missing')

        new_token = self._generate_token(user)
        refresh_token = self._generate_refresh_token()
        query = tokens.select().with_only_columns([tokens.c.id, tokens.c.token]).where(tokens.c.token == new_token)
        old_token = await self.db.fetch_one(query)
        if old_token is None:
            await self.db.execute(tokens.insert().values(token=new_token, user_id=user['id']))

        await self.db.execute(users.update().where(users.c.id == user['id']).values(refresh_token=refresh_token))

        return {'access_token': new_token, 'refresh_token': refresh_token}

    async def clear_old_token(self):
        query = tokens.select().with_only_columns([tokens.c.id, tokens.c.token])
        old_tokens = await self.db.fetch_all(query)
        for token in old_tokens:
            try:
                payload, header = self.token_serializer.loads(token['token'], return_header=True)
            except Exception as e:
                if isinstance(e, SignatureExpired):
                    query = tokens.delete().where(tokens.c.id == int(token['id']))
                    await self.db.execute(query)
