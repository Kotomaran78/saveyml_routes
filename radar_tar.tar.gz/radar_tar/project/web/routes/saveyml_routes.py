from sanic.response import json
import yaml

def save_data_to_yml(web, app):
    sanic = web.sanic

    @sanic.route('/save_data_to_yml', methods=["POST"])
    async def f_data(request):
        return await app.service.saveYamlService.save1(request)

    @sanic.route('/save_data_to_yml2', methods=["POST"])
    async def f_data(request):
        return await app.service.saveYamlService.save2(request)