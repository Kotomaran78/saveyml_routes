

def load_serial(web, app):
    auth = web.auth

    @web.route('/api/serial')
    @auth.login_required
    async def handler(request):
        return await app.service.serialService.current()

    @web.route('/api/serial', methods=['POST'])
    @auth.login_required
    async def handler(request):
        return await app.service.serialService.update(request.json)
