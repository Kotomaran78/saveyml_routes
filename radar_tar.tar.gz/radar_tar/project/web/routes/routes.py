from datetime import datetime
from json import dumps
from os import path

from sanic.exceptions import NotFound, ServerError
from sanic.response import file, json
from websockets.exceptions import ConnectionClosed
# from .tokenAuth import auth


def load_routes(web, app):
    # ee = app.event_emitter
    root = app.root
    service = app.service
    public = path.join(root, 'public')

    assets = path.join(public, 'static')

    sanic = web.sanic
    auth = web.auth
    # static path
    sanic.static('/static', assets)
    # auth = web.auth

    # WEB API


    @sanic.route("/")
    async def main_route(req):
        tmpl_file_path = path.join(public, 'index.html')
        return await file(tmpl_file_path)

    @web.route('/auth', methods=['POST'])
    async def handler(req):
        return await auth.auth_user(req)

    @web.route('/auth/me')
    @auth.login_required
    @auth.inject_user
    async def handler(req, user):
        return {"me": user}

    @web.route('/auth/refresh', methods=['POST'])
    @auth.login_required
    @auth.inject_user
    async def handler(req, user):
        return await auth.update_token(req, user)

    @web.route('/users')
    @auth.login_required
    async def handler(req):
        return await app.service.userService.list_users()

    @web.route('/users/<id>')
    @auth.login_required
    async def handler(req, id):
        return await app.service.userService.get_user(int(id))

    @web.route('/users', methods=['POST'])
    @auth.login_required
    async def handler(req):
        return await app.service.userService.create_user(req.json)

    @web.route('/users', methods=['PUT'])
    @auth.login_required
    @auth.inject_user
    async def handler(req, user):
        return await app.service.userService.update_password(req, user)

    @web.route('/users/<id>', methods=['DELETE'])
    @auth.login_required
    async def handler(req, id):
        return await app.service.userService.delete_user(id)

    @sanic.exception(NotFound, ServerError)
    def json_404s(request, exception):
        return json({'error': exception})

    @sanic.websocket('/feed')
    async def feed(request, ws):
        web.add_socket(ws)
        while True:
            try:
                message = await ws.recv()
            except ConnectionClosed:
                web.remove_socket(ws)
                break
            else:
                await web.send_all_sockets(dumps({
                    'event': 'pong',
                    'timestamp': datetime.now().isoformat(),
                }))
