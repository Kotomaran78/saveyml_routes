from os import path
from sanic.response import file

from sanic.response import json



def load_device(web, app):
    auth = web.auth
    sanic = web.sanic
    device = app.service.deviceService
    history = app.service.historyService

    @web.route('/api/devices/supported')
    @auth.login_required
    async def handler(request):
        return await device.support_devices()

    @web.route('/api/devices')
    @auth.login_required
    async def handler(request):
        return await device.device_list()

    @web.route('/api/devices/<device_type>/create', methods=['POST'])
    @auth.login_required
    async def handler(request, device_type):
        return await device.create_device(device_type, request)

    @web.route('/api/devices/<device_type>/registers')
    @auth.login_required
    async def handler(request, device_type):
        return await device.registers(device_type)



    @web.route('/api/devices/add_to_yml', methods=['POST'])
    # @auth.login_required
    async def handler(request):
        return await device.add_to_yml(request.json)



    @web.route('/api/devices/<device_type>/<device_id>', methods=['PUT'])
    @auth.login_required
    async def handler(request, device_type, device_id):
        return await device.update_device(device_type, device_id, request)

    @web.route('/api/devices/<device_type>/<device_id>', methods=['DELETE'])
    @auth.login_required
    async def handler(request, device_type, device_id):
        return await device.delete_device(device_type, device_id, request)

    @web.route('/api/devices/values', methods=['POST'])
    @auth.login_required
    async def handler(request):
        return await history.get_history(request.json)

    @web.route('/api/devices/values/create_csv', methods=['POST'])
    @auth.login_required
    async def handler(request):
        return await history.history_to_csv(request.json)

    @sanic.route('/api/devices/values/load_csv', methods=['POST'])
    @auth.login_required
    async def handler(request):
        return await file(path.join(app.history_folder, request.json['filepath']))

    @web.route('/api/devices/<device_type>/connected')
    @auth.login_required
    async def handler(request, device_type):
        return await device.list_devices(device_type)
