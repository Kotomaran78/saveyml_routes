from .AbsException import AbsException


class WebServerError(AbsException):
    code = 400
    message = "Error response"
    pass