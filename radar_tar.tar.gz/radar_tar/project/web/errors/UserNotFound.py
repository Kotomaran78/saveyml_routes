from .AbsException import AbsException


class UserNotFound(AbsException):
    code = 400
    message = "User not found"
    pass
