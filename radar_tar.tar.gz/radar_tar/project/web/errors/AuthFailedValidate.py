
from .AbsException import AbsException


class AuthFailedValidate(AbsException):
    code = 401
    message = "Missing username or password"
    pass
