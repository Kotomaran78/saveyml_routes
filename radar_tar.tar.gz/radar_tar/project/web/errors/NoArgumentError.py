from .AbsException import AbsException


class NoArgumentError(AbsException):
    # def __init__(self, message='Invalid arguments', code=400):
    #     self.message = message
    #     self.code = code

    code = 400
    message = "Invalid arguments"
    pass
