
from .AbsException import AbsException


class Unauthorized(AbsException):
    code = 401
    message = "Authorization header not present."
    pass
