from .AbsException import AbsException


class DuplicateDevice(AbsException):
    code = 400
    message = "The device already exists"
    pass
