from .AbsException import AbsException


class AuthFailed(AbsException):
    code = 401
    message = "User or password is incorrect"
    pass
