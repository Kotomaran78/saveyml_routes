class AbsException(Exception):
    """ Abstract exception. """
    def __init__(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)

    def __str__(self, *args, **kwargs):
        """ Return str(self). """
        return str(self.code) + ' ' + str(self.message)

    def __repr__(self):
        return self.__dict__

    def to_json(self):
        def translate_attr(attr):
            if isinstance(attr, int):
                return attr
            if isinstance(attr, float):
                return attr
            if isinstance(attr, str):
                return attr
            elif isinstance(attr, list):
                return list(attr)
            elif isinstance(attr, dict):
                return dict(attr)
            elif isinstance(attr, object):
                return attr.__dict__
            return attr

        return dict((k, translate_attr(getattr(self, k))) for k in self.__dict__)

    message = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """exception message"""

    code = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """exception code"""