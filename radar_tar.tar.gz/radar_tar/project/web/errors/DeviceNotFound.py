from .AbsException import AbsException


class DeviceNotFound(AbsException):
    code = 400
    message = "Device not found"
    pass
