
from .AbsException import AbsException


class AuthenticationFailed(AbsException):
    code = 401
    message = "Missing username or password."
    pass
