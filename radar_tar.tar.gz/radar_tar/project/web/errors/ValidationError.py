from .AbsException import AbsException


class ValidationError(AbsException):
    code = 400
    message = "Invalid arguments"
    pass
