import traceback
from asyncio import ensure_future, iscoroutine, sleep

import sanic.response as response
from sanic import Sanic
from sanic.exceptions import ServerError
from sanic_cors import CORS
from websockets.exceptions import ConnectionClosed

from project.app.mqmessages import getmqmessages
# from project.monitoring import DeviceChecker, StatusObserver, detectChanges, Exchanger
from project.web.errors import WebServerError, AbsException
from project.web.routes import *
from .routes import AuthRoutes


class Web:
    def __init__(self, app) -> None:
        super().__init__()
        self.__app = app
        self.loop = app.loop
        self.webconfig = self.__app.config['web']
        self.sockets = []
        self.sanic = Sanic(__name__)
        self.sanic.config.update(self.webconfig['sanic'])

        CORS(self.sanic, resources={r"/api/*": {"origins": "*"}, r"/auth/*": {"origins": "*"}}, automatic_options=True)

        self.auth = AuthRoutes(self)

        load_routes(self, self.__app)
        load_serial(self, self.__app)
        load_device(self, self.__app)
        load_config(self, self.__app)
        load_system(self, self.__app)
        save_data_to_yml(self, self.__app)

    @property
    def app(self):
        return self.__app

    def route(self, url, methods=None, fn=None):

        if methods is None:
            methods = ['GET']

        def _route(fn):

            async def fn_executor(*args, **kwargs):
                error = None
                try:
                    result = fn(*args, **kwargs)
                    if iscoroutine(result):
                        result = await result
                    return response.json(result)
                except Exception as e:
                    if isinstance(e, AbsException):
                        error = WebServerError(
                            data=e.to_json(),
                            error=e.__class__.__name__,
                            message=e.message,
                            trace=traceback.format_exc().split('\n'),
                            code=e.code
                        )
                    else:
                        return response.json(e)
                except ServerError as e:
                    if isinstance(e, AbsException):
                        error = WebServerError(
                            data=e.to_json(),
                            error=e.__class__.__name__,
                            message=e.message,
                            trace=traceback.format_exc().split('\n'),
                            code=e.code
                        )
                    else:
                        return response.json(e)

                return response.json(error.to_json(), status=error.code)

            self.sanic.add_route(fn_executor, url, methods=methods)
            return fn

        if fn is None:
            return _route

        return _route(fn)

    def start(self):
        self._init_web_server()

        # self._init_mqobserver()

        """
        Disabled
        not in use
        """
        # self._init_device_checker()
        # task3 = ensure_future(detectChanges(self.deviceChecker))

    def _init_web_server(self):
        server = self.sanic.create_server(host=self.webconfig['host'],
                                          port=self.webconfig['port'],
                                          debug=self.webconfig['debug'],
                                          return_asyncio_server=True)
        self.sanic.add_task(self._init_mqobserver())
        self.sanic.add_task(self._clear_old_tokens())
        task = ensure_future(server)

    async def _init_mqobserver(self):
        await sleep(5)

        """
        Initialize mq messages observer
        getter message from devices and write it to db
        """
        self.mqChecker = self.app.service.mqChecker
        self.mqObserver = self.app.service.mqObserver
        self.mqChecker.attach(self.mqObserver)
        task2 = ensure_future(getmqmessages(self.app, self.mqChecker))

    async def _clear_old_tokens(self):
        await sleep(60)
        while True:
            await self.auth.clear_old_token()
            await sleep(60)

    # def _init_device_checker(self):
    #     self.deviceExchanger = Exchanger(self.app)
    #     self.deviceChecker = DeviceChecker(self.app, self.deviceExchanger)
    #     self.statusObserver = StatusObserver(self.app, self.deviceExchanger)
    #     self.deviceChecker.attach(self.statusObserver)

    def add_socket(self, socket):
        self.sockets.append(socket)

    def remove_socket(self, socket):
        try:
            self.sockets.remove(socket)
        except ValueError:
            pass  # already removed

    async def send_all_sockets(self, data):
        for socket in self.sockets:
            try:
                await socket.send(data)
            except ConnectionClosed:
                self.remove_socket(socket)
