from sanic.response import HTTPResponse, json
from secure import SecureHeaders

secure_headers = SecureHeaders()


def setup_middlewares(sanic):
    @sanic.middleware('response')
    async def set_secure_headers(request, response):
        secure_headers.sanic(response)


def setup_version(app):
    sanic = app.web.sanic
    web = app.web

    @sanic.middleware('response')
    async def custom_header(request, response):
        response.headers.add('Access-Control-Expose-Headers', 'Version')
        response.headers["Version"] = app.version
