from .BaseDevice import BaseDevice


class GpioDevice(BaseDevice):
    def __init__(self, app):
        super().__init__(app)
        self._device_name = 'gpio'

    async def _db_device(self, device_data):
        pass

    async def update_device_config(self, deviceId, device_data, registers_data):
        pass

    async def create_db_device(self, device_data):
        pass

    async def update_device(self, gpo_id, data):
        if 'value' not in data:
            return

        config = await self._config()
        gpo = config['gpio']['gpo']

        gpo = [x for x in gpo if gpo[x]['gpio'] == int(gpo_id)]

        if len(gpo) == 0:
            return
        gpo = gpo[0]

        self.ee.emit('relay:update', gpo, data['value'])
        return True

    async def registers(self):
        return await self._config()


class GpioBuilder:
    def __init__(self, app):
        self._app = app

    def __call__(self, *args, **kwargs):
        return GpioDevice(self._app)
