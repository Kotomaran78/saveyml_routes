from os import getenv

from project.db import device
from .BaseDevice import BaseDevice


class Mercury236Device(BaseDevice):
    def __init__(self, app):
        super().__init__(app)
        self._device_name = 'mercury_236'

    async def _db_device(self, device_obj):
        device_data = device_obj['device']
        registers_data = device_obj['registers']

        device_query = device.insert().values(
            device=device_data['device'],
            slave_id=device_data['slave_id'],
            topic=device_data['topic'],
            port=device_data['port'],
            interval=device_data['interval'],
            history=device_data['history'],
            registers=registers_data,
            password=device_data['password']
        )
        return await self._save_db_device(device_query)

    async def update_device_config(self, device_id, device_data, registers_data):
        config = await self._device_config()

        port = await self._real_serial(device_data['port'])

        config[int(device_id)] = {
            "config": {
                "poll_interval": device_data['interval'],
                "read_on_request": True
            },
            "device": {
                "address": device_data['slave_id'],
                "serial": '/dev/' + port,
                "passwd": device_data['password']
            },
            "send_in_status": registers_data
        }

        await self._update_config(config)

    async def create_db_device(self, device_obj):
        await self.validate(device_obj)

        device_data = device_obj['device']
        registers_data = device_obj['registers']

        device_id = await self._db_device(device_obj)

        await self.update_device_config(device_id, device_data, registers_data)

        if self.app.test_run:
            return device_id

        await self._create_query(device_id)

        await self.service_command('start', device_id)
        await self.service_command('enable', device_id)

        return device_id

    async def update_device(self, mercury236_id, device_obj):
        await self.validate(device_obj)

        db_device = await self._get_device(mercury236_id)
        device_data = device_obj['device']
        registers_data = device_obj['registers']

        password = device_data['password']
        del device_data['password']

        updated_device = {
            **dict(db_device.items()),
            **device_data
        }
        await self.db.execute(
            device.update().where(device.c.id == int(mercury236_id)).values(**updated_device))

        updated_device['password'] = password
        await self.update_device_config(mercury236_id, updated_device, registers_data)

        if self.app.test_run:
            return updated_device

        await self.service_command('restart', mercury236_id)

        return updated_device

    async def delete_device(self, device_id, request):
        return await self._delete_device(device_id, request)

    async def _restore_config(self, device_obj):
        new_config = {
            device_obj['id']: {
                "config": {
                    "poll_interval": device_obj['interval'],
                    "read_on_request": True
                },
                "device": {
                    "address": device_obj['slave_id'],
                    "passwd": device_obj['password'],
                    "serial": '/dev/' + await self._real_serial(device_obj['port'])
                },
                "send_in_status": device_obj['registers']
            }
        }
        config = await self._config()

        if config is not None:
            if int(device_obj['id']) in config:
                config[int(device_obj['id'])] = new_config
            else:
                config.update(new_config)
        else:
            config = {}
            config.update(new_config)

        await self._update_config(config)

    async def get_device(self, device_obj):
        config = await self._config()
        if config is not None and int(device_obj['id']) in config:
            device_config = config[int(device_obj['id'])]
        else:
            await self._restore_config(device_obj)
            return device_obj

        if 'passwd' in device_config['device']:
            device_obj['password'] = device_config['device']['passwd']

        return device_obj

    async def registers(self):
        return self.app.registers236


class Mercury236Builder:
    def __init__(self, app):
        self._app = app

    def __call__(self, *args, **kwargs):
        return Mercury236Device(self._app)
