
class DeviceFactory:
    def __init__(self, app):
        self.app = app
        self._device_builder = {}

    def register_device(self, key, device_builder):
        self._device_builder[key] = device_builder

    def create(self, key, **kwargs):
        device_builder = self._device_builder.get(key)
        if not device_builder:
            raise ValueError(key)

        return device_builder(**kwargs)
