from os import path, fsync, system, getenv
import asyncio
import jsonschema
import pika
from jsonschema import validate
from yaml import safe_dump, safe_load

from project.db import device, history
from project.schema import load_schema
from project.web.errors import ValidationError, DeviceNotFound, DuplicateDevice
from asyncpg.exceptions import UniqueViolationError


class BaseDevice:
    def __init__(self, app):
        self._app = app
        self._device_name = None

    @property
    def app(self):
        return self._app

    @property
    def db(self):
        return self._app.db

    @property
    def ee(self):
        return self._app.event_emitter

    async def _config(self):
        try:
            with open(
                    path.join(self._app.device_root, self._device_name + '.yml'),
                    'r',
                    encoding='utf-8'
            ) as f:
                loaded_conf = safe_load(f.read())
                f.close()
        except IOError:
            loaded_conf = {}
            with open(
                    path.join(self._app.device_root, self._device_name + '.yml'),
                    'w+',
                    encoding='utf-8'
            ) as f:
                f.write(safe_dump(loaded_conf))
                f.flush()
                fsync(f.fileno())
                f.close()
        return loaded_conf

    async def _registers(self):
        with open(
                path.join(self._app.device_root, 'registry/'+ self._device_name + '.yml'),
                'r',
                encoding='utf-8'
        ) as f:
            loaded_conf = safe_load(f.read())
            f.close()
        return loaded_conf

    async def _update_config(self, new_config):
        with open(path.join(self._app.device_root, self._device_name + '.yml'), "w+") as mercf:
            mercf.write(safe_dump(new_config))
            mercf.flush()
            fsync(mercf.fileno())
            mercf.close()

    async def _get_device(self, device_id):
        query = device.select().where(device.c.id == int(device_id))
        db_device = await self.db.fetch_one(query)
        if db_device is None:
            raise DeviceNotFound()
        return db_device

    async def _create_query(self, device_id):
        credentials = pika.PlainCredentials(self.app.config['mq']['username'], self.app.config['mq']['password'])

        parameters = pika.ConnectionParameters(host=self.app.config['mq']['host'], credentials=credentials)
        connection = pika.BlockingConnection(parameters)
        channel = connection.channel()
        channel.queue_declare(queue=f'{self._device_name}@{device_id}.command', durable=True)
        channel.queue_bind(queue=f'{self._device_name}@{device_id}.command', exchange='device', routing_key=f'{self._device_name}@{device_id}.command')
        channel.queue_declare(queue=f'{self._device_name}@{device_id}.info', durable=True)
        channel.queue_bind(queue=f'{self._device_name}@{device_id}.info', exchange='device', routing_key=f'{self._device_name}@{device_id}.info')
        channel.queue_declare(queue=f'{self._device_name}@{device_id}.info_reply', durable=True)
        channel.queue_bind(queue=f'{self._device_name}@{device_id}.info_reply', exchange='device',
                           routing_key=f'{self._device_name}@{device_id}.info_reply')
        connection.close()

    async def _real_serial(self, web_port):
        serials = await self.app.service.serialService.current()
        rs_value = web_port.replace(' #', '_').replace('-', '').lower()
        return serials[rs_value]['device']

    async def service_command(self, command, device_id):
        system(f'systemctl {command} {self._device_name}@{device_id}')

    async def validate(self, device_obj):
        device_schema = load_schema(self._app, f'{self._device_name}.schema.json')

        try:
            validate(device_obj, device_schema)
        except jsonschema.exceptions.ValidationError as err:
            raise ValidationError(message=err.message)

    async def _save_db_device(self, device_query):
        try:
            device_id = await self.db.execute(device_query)
        except UniqueViolationError as e:
            raise DuplicateDevice(message="The device already exists")

        return device_id

    async def _device_config(self):
        device_config = await self._config()
        if device_config is None:
            device_config = {}
        return device_config

    async def device_registers(self, device):
        id = device['id']

        config = await self._config()
        try:
            return config[int(id)]['send_in_status']
        except:
            if device['registers'] is None:
                return []
            return device['registers']

    async def _delete_device(self, device_id, request):
        db_device = await self._get_device(device_id)
        db_device = dict(db_device.items())
        delete_device_query = device.delete().where(device.c.id == int(device_id))
        device_name = 'ds18b20' if db_device['device'] == '1-wire' else db_device['device']
        clear_history_query = history.delete().where(history.c.device == f"{device_name}@{db_device['id']}")


        """
        Stoping device services
        """
        if not self.app.test_run:
            await self.service_command('stop', device_id)
            await self.service_command('disable', device_id)

        """
        Delete device instance in db
        """
        try:
            await self.db.execute(delete_device_query)
        except Exception as e:
            return False

        """
        Delete device instance in config
        """
        config = await self._config()
        del config[int(device_id)]
        await self._update_config(config)

        try:
            await asyncio.sleep(1)
            await self.db.execute(clear_history_query)
        except Exception as e:
            return False

        return True
