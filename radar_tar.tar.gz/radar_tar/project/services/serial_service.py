from os import path, fsync, system
import pyudev
import jsonschema
from jsonschema import validate
from yaml import safe_load, safe_dump

from project.schema import load_schema
from project.web.errors import ValidationError
from .BaseService import BaseService


class SerialService(BaseService):
    def __init__(self, app):
        super().__init__(app)
        self._serials = None
        self.init_config()

    def init_config(self):
        self._serials = self.initial_status()

    def _detect_tty_ports(self):
        ports = []
        context = pyudev.Context()
        for device in context.list_devices(subsystem='tty'):
            if 'virtual' in device.get('DEVPATH'):
                continue
            ports.append(device.get('DEVNAME'))

        return ports

    def initial_status(self):
        current_system_ports = self._detect_tty_ports()
        loaded_conf = self.read_config()

        rsconfig = [{x:loaded_conf['serial'][x]} for x in loaded_conf['serial'] if 'config' not in x]
        new_dict = {}
        for item in rsconfig:
            for value in item.values():
                value['enabled'] = False
                for csport in current_system_ports:
                    if value['device'] in csport:
                        value['enabled'] = True
            new_dict.update(**item)
        return new_dict

    def read_config(self):
        try:
            with open(
                    path.join(self._app.device_root, 'serial.yml'),
                    'r',
                    encoding='utf-8'
            ) as f:
                loaded_conf = safe_load(f.read())
                f.close()
        except IOError:
            """
            Serial config not found
            create empty config
            stop all device services
            """
            loaded_conf = {
                "serial": {
                    'config': {
                        "poll_interval": 5000
                    }
                }
            }

            system('systemctl stop serial')
            system('systemctl stop mercury_206@*')
            system('systemctl stop mercury_236@*')
            system('systemctl stop ds18b20@*')

            with open(path.join(self._app.device_root, 'serial.yml'), "x") as serialf:
                serialf.write(safe_dump(loaded_conf))
                serialf.flush()
                fsync(serialf.fileno())
                serialf.close()

        return loaded_conf

    async def current(self):
        if self._serials is None:
            self.init_config()
        return self._serials

    async def update(self, data):
        serial_schema = load_schema(self._app, 'serial.schema.json')

        try:
            validate(data, serial_schema)
        except jsonschema.exceptions.ValidationError as err:
            raise ValidationError(message=err.message)

        with open(
                path.join(self._app.device_root, 'serial.yml'),
                'r',
                encoding='utf-8'
        ) as f:
            loaded_conf = safe_load(f.read())
            f.close()

        data = data['serials']
        for port in data:
            if 'enabled' in data[port]:
                del data[port]['enabled']

        self.ee.emit('serial:config', data)

        if 'config' not in loaded_conf['serial']:
            mq_config = {"poll_interval": 5000}
        else:
            mq_config = loaded_conf['serial']['config']

        loaded_conf['serial'] = data
        loaded_conf['serial'].update({'config': mq_config})
        with open(path.join(self._app.device_root, 'serial.yml'), "w+") as serialf:
            serialf.write(safe_dump(loaded_conf))
            serialf.flush()
            fsync(serialf.fileno())
            serialf.close()
        return True

    async def config_update(self, data):
        for port in data:
            if port == 'config':
                continue
            if port in self._serials:
                if data[port] != self._serials[port]:
                    self.ee.emit('serial:update', port, data[port])
            else:
                self.ee.emit('serial:update', port, data[port])
