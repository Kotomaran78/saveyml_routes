from sanic.response import json

import yaml

class SaveYamlService():
    def __init__(self, app):
        super().__init__()

    async def save1(self, arg):
        with open('save_data_to_yml.yml', 'w') as f:
            yaml.dump(arg.body, f, default_flow_style=False)
        return json({"message":"Ok"})

    async def save2(self, arg):
        with open('save_data_to_yml2.yml', 'w') as f:
            yaml.dump(arg.body, f, default_flow_style=False)
        return json({"message":"Ok"})