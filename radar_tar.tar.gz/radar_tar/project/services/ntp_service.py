from os import path, system, getenv

import jsonschema
from jsonschema import validate

from project.schema import load_schema
from project.web.errors import ValidationError
from .BaseService import BaseService


class NtpService(BaseService):
    def __init__(self, app):
        super().__init__(app)
        self.config = app.config
        self.ntp_config = self._detect_ntp_config()

    def _detect_ntp_config(self):
        if self.app.test_run:
            return path.join(self.app.root, 'tests/ntp.conf')

        ntp_config = getenv('NTP_CONF')
        return path.join(self.app.root, ntp_config)

    def get_ntp(self, data):
        if 'ntp' in self.config:
            return self.config['ntp']
        else:
            return []

    async def current_ntps(self, data):
        ntps = self.get_ntp(data)
        time = self._app.get_time()
        ntp_servers = {
            "server1": "",
            "server2": "",
            "server3": "",
            "server4": "",
        }
        serverstr = 1
        for server in ntps:
            ntp_servers['server' + str(serverstr)] = server
            serverstr += 1
        return {
            "ntps": ntp_servers,
            "time": time
        }

    async def update_ntp(self, data):
        ntp_schema = load_schema(self._app, 'ntp.schema.json')

        try:
            validate(data, ntp_schema)
        except jsonschema.exceptions.ValidationError as err:
            raise ValidationError(message=err.message)

        ntp = data['ntps']

        servers = []

        if isinstance(ntp, str):
            servers = [ntp]
        if isinstance(ntp, dict):
            servers = list(ntp.values())
        with open(self.ntp_config) as nf:
            ntp_lines = nf.read().splitlines()
            nf.close()
        skip_servers = False
        with open('/tmp/tmp_ntp', "w+") as tn:
            for line in ntp_lines:
                if 'pool ' in line or 'server ' in line:
                    if skip_servers:
                        continue
                    if 'server ' in line:
                        word = 'server'
                    if 'pool ' in line:
                        word = 'pool'
                    for server in servers:
                        line = f"{word} {server} iburst minpoll 6 maxpoll 5"
                        tn.write(line + '\n')
                    skip_servers = True
                    continue
                if line == '\n':
                    continue
                tn.write(line + '\n')
            tn.close()

        system(f'mv /tmp/tmp_ntp {self.ntp_config}')
        if not self.app.test_run:
            # system('systemctl restart ntp')
            self.config['ntp'] = servers
            self.app.updateConfig()
        return True
