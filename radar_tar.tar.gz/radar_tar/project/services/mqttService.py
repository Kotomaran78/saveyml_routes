from os import path, mkdir
import jsonschema
from jsonschema import validate

from project.schema import load_schema
from project.web.errors import ValidationError


class MqttService:
    def __init__(self, app):
        self._app = app
        self._mqttConfig = self._app.config['mqtt']

    @property
    def app(self):
        return self._app

    async def current(self):
        # TODO LOAD FROM FILE OR MEMORY?
        return self._mqttConfig

    async def update_setting(self, request, server_index):
        data = {}
        for key in request.form.keys():
            data[key] = request.form[key][0]

        try:
            data['port'] = int(data['port']) if data['port'] != "" else None
            data['keepalive'] = int(data['keepalive']) if data['keepalive'] != "" else None
            data['timeout'] = int(data['timeout']) if data['timeout'] != "" else None
            data['reconnect'] = int(data['reconnect']) if data['reconnect'] != "" else None
            data['qos'] = int(data['qos']) if data['qos'] != "" else None
            data['gwport'] = int(data['gwport']) if data['gwport'] != "" else None
        except Exception as e:
            raise Exception
        mqtt_schema = load_schema(self._app, 'mqtt.schema.json')

        try:
            validate(data, mqtt_schema)
        except jsonschema.exceptions.ValidationError as err:
            raise ValidationError(message=err.message)
        ca_file = None
        cert_file = None
        key_file = None
        if data['protocol'].lower() =='mqtt/tls' or data['protocol'].lower() =='wss':
            caraw = request.files.get('ca')
            if caraw is not None:
                ca_file = {
                    'body': caraw.body,
                    'name': caraw.name,
                    'type': caraw.type,
                }
            certraw = request.files.get('cert')
            if certraw is not None:
                cert_file = {
                    'body': certraw.body,
                    'name': certraw.name,
                    'type': certraw.type,
                }
            keyraw = request.files.get('key')
            if keyraw is not None:
                key_file = {
                    'body': keyraw.body,
                    'name': keyraw.name,
                    'type': keyraw.type,
                }

        if not path.exists(path.join(self.app.cert_folder, server_index)):
            mkdir(path.join(self.app.cert_folder, server_index))

        if ca_file is not None:
            file_path = path.join(path.join(self.app.cert_folder, server_index), ca_file['name'])
            with open(file_path, 'wb') as caw:
                caw.write(ca_file['body'])
                data['ca'] = ca_file['name']
        if cert_file is not None:
            file_path = path.join(path.join(self.app.cert_folder, server_index), cert_file['name'])
            with open(file_path, 'wb') as caw:
                caw.write(cert_file['body'])
                data['cert'] = cert_file['name']
        if key_file is not None:
            file_path = path.join(path.join(self.app.cert_folder, server_index), key_file['name'])
            with open(file_path, 'wb') as caw:
                caw.write(key_file['body'])
                data['key'] = key_file['name']

        self._mqttConfig[server_index] = data

        self.app.config['mqtt'] = self._mqttConfig
        self.app.updateConfig()
        # self.app.event_emitter.emit('mqtt:disconnect')

        return True
