import bcrypt
import jsonschema
from jsonschema import validate

from project.db.tables import users
from project.schema import load_schema
from project.web.errors import ValidationError, UserNotFound, AuthenticationFailed
from .BaseService import BaseService


class UserService(BaseService):
    def __init__(self, app):
        super().__init__(app)

    def __crypt_pass(self, password):
        password = password.encode('utf-8')
        salt = bcrypt.gensalt()
        return bcrypt.hashpw(password, salt)

    async def list_users(self):
        query = users.select().with_only_columns([users.c.id, users.c.username])
        usersRow = await self._app.db.fetch_all(query)
        return [(dict(user.items())) for user in usersRow]

    async def get_user(self, user_id):
        query = users.select().with_only_columns([users.c.id, users.c.username]).where(users.c.id == user_id)
        user = await self._app.db.fetch_one(query)
        if not user:
            raise UserNotFound()

        return dict(user.items())

    async def create_user(self, data):
        user_schema = load_schema(self._app, 'user.schema.json')

        try:
            validate(data, user_schema)
        except jsonschema.exceptions.ValidationError as err:
            raise ValidationError(message=err.message)

        insertQuery = users.insert().values(username=data['username'], password=self.__crypt_pass(data['password']))
        userId = await self._app.db.execute(insertQuery)
        query = users.select().with_only_columns([users.c.id, users.c.username]).where(users.c.id == userId)
        user = await self._app.db.fetch_one(query)
        return dict(user.items())

    async def delete_user(self, user_id):
        query = users.select().with_only_columns([users.c.id, users.c.username]).where(users.c.id == int(user_id))
        user = await self._app.db.fetch_one(query)
        if not user:
            raise UserNotFound()

        deleteQuery = users.delete().where(users.c.id == int(user_id))
        await self._app.db.execute(deleteQuery)

        return True

    async def update_password(self, request, admin):
        data = request.json
        pwd_schema = load_schema(self._app, 'resetpwd.schema.json')

        try:
            validate(data, pwd_schema)
        except jsonschema.exceptions.ValidationError as err:
            raise ValidationError(message=err.message)

        old_password = request.json.get("current", None).encode('utf-8')
        new_password = request.json.get("new_password", None).encode('utf-8')

        salt = bcrypt.gensalt()
        hashed = bcrypt.hashpw(new_password, salt)

        query = users.select().with_only_columns([users.c.id, users.c.password, users.c.username]).where(
            users.c.username == admin['username'])
        user = await self._app.db.fetch_one(query)

        to_dict = lambda r: {k: v for k, v in r.items()}
        user = to_dict(user)

        if not bcrypt.checkpw(old_password, user['password']):
            raise AuthenticationFailed(message="Password is incorrect.")

        await self._app.db.execute(users.update().where(users.c.id == admin['id']).values(password=hashed))

        return True