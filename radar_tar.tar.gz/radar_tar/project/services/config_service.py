import os

import jsonschema
from jsonschema import validate
import subprocess

from project.schema import load_schema
from project.web.errors import ValidationError
from .BaseService import BaseService
from .mqttService import MqttService
from .network import Network


class ConfigService(BaseService):
    def __init__(self, app):
        super().__init__(app)
        self._networkService = Network(app)
        self._mqttService = MqttService(app)

    @property
    def config(self):
        return self.app.config

    async def free_spacefs(self):
        st = os.statvfs("/")
        du = st.f_bsize * st.f_bavail / 1024 / 1024
        return du

    async def total_spacefs(self):
        st = os.statvfs("/")
        total = st.f_blocks * st.f_frsize
        return total /1024/1024

    async def status(self):
        network = await self._networkService.get_network()
        device_id = self.config['device']['id']
        time = self._app.get_time()
        return {
            'device_id': device_id,
            "time": time,
            'active_connection': network['active_connection'],
            "free_space": await self.free_spacefs(),
            "total_space": await self.total_spacefs(),
            "main_mqtt_server": self.config['mqtt']['main']['host']
        }

    async def get_locale(self):
        return self.config['device']['locale']

    async def locale(self, request):
        data = request.json
        locale_schema = load_schema(self.app, 'locale.schema.json')

        try:
            validate(data, locale_schema)
        except jsonschema.exceptions.ValidationError as err:
            raise ValidationError(message=err.message)

        self.config['device']['locale'] = data['locale']
        self._app.updateConfig()
        return True

    async def network(self, request):
        return await self._networkService.get_network()

    async def update_network(self, request):
        return await self._networkService.update_network(request.json)

    async def mqtt(self, request):
        return await self._mqttService.current()

    async def update_mqtt(self, request, server_index):
        return await self._mqttService.update_setting(request, server_index)

    async def time(self, request):
        time = self.app.get_time()
        ntps = self.service.ntpService.get_ntp(request)
        return {
            "time": time,
            "ntps": ntps
        }

    async def auth(self, request):
        return True

    async def update(self, request):
        return True

    async def reboot(self, request):
        if self.app.test_run:
            return True

        self.ee.emit('system:reboot')
        return True

    async def reset(self, request):
        return True

    async def ssh_status(self):
        status = subprocess.check_output('systemctl show -p ActiveState --value ssh', shell=True)
        status = status.decode().splitlines()[0]
        print(status)
        return True if status == 'active' else False

    async def ssh_update(self, params):
        print(params)
        ssh_schema = load_schema(self.app, 'sshparams.schema.json')

        try:
            validate(params, ssh_schema)
        except jsonschema.exceptions.ValidationError as err:
            raise ValidationError(message=err.message)

        if params['enable']:
            os.system('systemctl enable ssh')
            os.system('systemctl start ssh')
        if not params['enable']:
            os.system('systemctl disable ssh')
            os.system('systemctl stop ssh')
        return await self.ssh_status()
