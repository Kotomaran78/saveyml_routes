

class BaseService:
    def __init__(self, app):
        self._app = app

    @property
    def app(self):
        return self._app

    @property
    def db(self):
        return self.app.db

    @property
    def ee(self):
        return self._app.event_emitter

    @property
    def service(self):
        return self._app.service
