import jsonschema
from aiotraceroute import aiotraceroute
from jsonschema import validate
from pythonping import ping

from project.schema import load_schema
from project.web.errors import ValidationError
from .BaseService import BaseService


class SystemService(BaseService):
    def __init__(self, app):
        super().__init__(app)

    async def ping(self, data):
        ping_schema = load_schema(self._app, 'ping.schema.json')
        try:
            validate(data, ping_schema)
        except jsonschema.exceptions.ValidationError as err:
            raise ValidationError(message=err.message)
        data = data['pingParams']
        response = ping(data['host'], verbose=False, size=data['size'], timeout=data['timeout'], count=data['count'])
        return [str(x) for x in response]

    async def trace(self, data):
        trace_schema = load_schema(self._app, 'trace.schema.json')
        try:
            validate(data, trace_schema)
        except jsonschema.exceptions.ValidationError as err:
            raise ValidationError(message=err.message)
        data = data['traceParams']
        ttl = 0
        async for n, addr, host in aiotraceroute(data['host']):
            ttl += 1
            if ttl >= data['ttl']:
                self.ee.emit('trace:hop', f'{n}   {addr}    {host}')