from .BaseService import BaseService
from project.services.devices import DeviceFactory
from project.services.devices import Mercury206Builder
from project.services.devices import Mercury236Builder
from project.services.devices import OneWireBuilder
# from project.services.devices import GpioBuilder
from project.services.devices import GanjubusBuilder
from project.db import device, history

import yaml
import json



class DeviceService(BaseService):
    def __init__(self, app):
        super().__init__(app)
        self.device_config_root = self._app.device_root
        self._device_factory = DeviceFactory(self._app)
        self.__init_builders()

    def __init_builders(self):
        # self._device_factory.register_device('mercury_206', Mercury206Builder(self._app))
        # self._device_factory.register_device('mercury_236', Mercury236Builder(self._app))
        # self._device_factory.register_device('1-wire', OneWireBuilder(self._app))
        # self._device_factory.register_device('gpio', GpioBuilder(self._app))
        self._device_factory.register_device('ganjubus', GanjubusBuilder(self._app))

    def _get_device_builder(self, device_type):
        device_builder = self._device_factory.create(device_type)
        return device_builder

    async def support_devices(self):
        return [
            {
                "text": "ganjubus",
                "value": "ganjubus"
            }
        ]

    async def registers(self, device_type):
        device_builder = self._device_factory.create(device_type)
        return await device_builder.registers()




    async def add_to_yml(self, arg):
        dic = arg

        with open('registry_ganjubus.yml','r') as yamlfile:
            cur_yaml = yaml.load(yamlfile)
            for lin in dic:
                cur_yaml[lin].update(dic[lin])

        with open('registry_ganjubus.yml','w') as yamlfile:
            yaml.dump(cur_yaml, yamlfile, default_flow_style=False)

        return {"message":"Ok"}






    async def list_devices(self, device_type):
        device_builder = self._device_factory.create(device_type)
        return await device_builder.list_connected()

    async def device_list(self):
        query = device.select()
        devices = await self.db.fetch_all(query)
        out_data = []
        for devicer in devices:
            device_obj = dict(devicer.items())
            device_builder = self._device_factory.create(device_obj['device'])
            registers = await device_builder.device_registers(device_obj)
            device_obj = await device_builder.get_device(device_obj)

            del device_obj['registers']
            if device_obj['device'] == 'ganjubus':
                del device_obj['address']

            out_data.append({
                "device": device_obj,
                "registers": registers
            })

        return out_data

    async def create_device(self, device_type, request):
        device_builder = self._get_device_builder(device_type)

        db_device = await device_builder.create_db_device(request.json)

        return db_device

    async def update_device(self, device_type, device_id, request):
        device_builder = self._get_device_builder(device_type)
        return await device_builder.update_device(device_id, request.json)

    async def delete_device(self, device_type, device_id, request):
        device_builder = self._get_device_builder(device_type)
        return await device_builder.delete_device(device_id, request)

    # TODO !!!!!!!!!!
    # async def device_list(self, req):
    #     query = device.select()
    #     devices = await self.db.fetch_all(query)
    #     config = self.mercuryConfig()
    #     out_data = []
    #     for devicer in devices:
    #         device_items = dict(devicer.items())
    #         registers = config[device_items['id']] if device_items['id'] in config else []
    #
    #         out_data.append({
    #             "device": device_items,
    #             "registers": registers['send_in_status'] if 'send_in_status' in registers else []
    #         })
    #
    #     return out_data

