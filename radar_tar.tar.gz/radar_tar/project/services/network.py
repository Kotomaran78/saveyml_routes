from os import system, path
import subprocess

import jsonschema
import netifaces as ni
from jsonschema import validate

from project.schema import load_schema
from project.web.errors import ValidationError


class Network:
    def __init__(self, app):
        self._app = app
        self.wpa_type = 'client'
        self.wifiEnabled = False
        self.wifiType = 'client'
        self.ethDev = self.getLanIface()
        self._dhcpcd_path = self._network_config_file()

    @property
    def app(self):
        return self._app

    @property
    def service(self):
        return self.app.service

    @property
    def networkConfig(self):
        return self._app.config['network']

    def _network_config_file(self):
        # if self.app.test_run:
        return path.join(self._app.root, 'tests/dhcpcd.conf')
        # return '/etc/dhcpcd.conf'

    def listInterfaces(self):
        ifaces = []
        if_list = ni.interfaces()
        for iface in if_list:
            if 'en' in iface:
                ifaces.append(iface)
            if 'et' in iface:
                ifaces.append(iface)
            if 'wl' in iface:
                ifaces.append(iface)
        return ifaces

    def getLanIface(self):
        if_list = ni.interfaces()
        return next((lan for lan in if_list if 'en' in lan), 'eth0')

    def str2bool(self, string):
        if isinstance(string, str):
            return string.lower() in ('yes', 'true', 't', '1')
        if isinstance(string, bool):
            return string

    async def get_network(self):
        if_list = self.listInterfaces()

        LAN1 = 'enp2s0'
        LAN2 = 'wlp3s0'
        MOBILE = None

        if 'interfaces' in self.networkConfig and 'LAN1' in self.networkConfig['interfaces']:
            LAN1 = self.networkConfig['interfaces']['LAN1']
        if 'interfaces' in self.networkConfig and 'LAN2' in self.networkConfig['interfaces']:
            LAN2 = self.networkConfig['interfaces']['LAN2']
        if 'interfaces' in self.networkConfig and 'MOBILE' in self.networkConfig['interfaces']:
            MOBILE = self.networkConfig['interfaces']['MOBILE']

        network_list = {
            "lan1": {
                "dev": LAN1,
                "active": False
            },
            "lan2": {
                "dev": LAN2,
                "active": False
            },
            "mobile": {
                "dev": MOBILE,
                "active": False
            }
        }
        params = {}

        for if_device in network_list:
            if network_list[if_device]['dev'] in if_list:
                params[if_device] = self._read_params_dhcpcd(network_list[if_device]['dev'])
                try:
                    fileData = open(f"/sys/class/net/{network_list[if_device]['dev']}/operstate", 'r')
                    status = fileData.readline().splitlines()[0]
                except:
                    status = 'up' if if_device.lower() == 'lan1' else 'down'
                params[if_device]['active'] = True if status == 'up' else False
            else:
                params[if_device] = network_list[if_device]

        active_connection = None
        for dev in self.networkConfig['priority']:
            if network_list[dev.lower()]['dev'] is not None:
                try:
                    fileData = open(f"/sys/class/net/{network_list[dev.lower()]['dev']}/operstate", 'r')
                    status = fileData.readline().splitlines()[0]
                except:
                    status = 'up' if dev.lower() == 'lan1' else 'down'
                if params[dev.lower()]['active'] and status == 'up':
                    active_connection = dev.lower()
                    break

        return {**params, "active_connection": active_connection, "priority": self.networkConfig['priority']}

    async def update_network(self, params):
        network_schema = load_schema(self._app, 'network.schema.json')

        try:
            validate(params, network_schema)
        except jsonschema.exceptions.ValidationError as err:
            raise ValidationError(message=err.message)

        self._write_network_params(params)
        return True

    def _cidr_to_netmask(self, cidr):
        import socket
        import struct
        network, net_bits = cidr.split('/')
        host_bits = 32 - int(net_bits)
        netmask = socket.inet_ntoa(struct.pack('!I', (1 << 32) - (1 << host_bits)))
        return network, netmask

    def append_cidr_suffix(self, full_ip):
        address_and_mask = full_ip.split('/')
        prefix = address_and_mask[0]
        ip_mask = address_and_mask[1]

        suffix = sum(bin(int(sub_part)).count('1') for sub_part in ip_mask.split('.'))

        return prefix + '/' + str(suffix)

    def _read_params_dhcpcd(self, dev):
        dev_link = ni.AF_INET if ni.AF_INET in ni.ifaddresses(f'{dev}') else ni.AF_LINK
        address = None
        gateway = None
        dns_servers = None
        metric = 200
        dhcp = True
        dev_part = False

        with open(self._dhcpcd_path, 'r') as dcf:
            iface_lines = dcf.read().splitlines()
            for line in iface_lines:
                if f'interface {dev}' in line:
                    dev_part = True
                    continue
                if dev_part:
                    if 'static ip_address=' in line:
                        address = line.replace('static ip_address=', '')
                        dhcp = False
                        continue
                    if 'static routers=' in line:
                        gateway = line.replace('static routers=', '')
                        continue
                    if 'static domain_name_servers=' in line:
                        dns_servers = line.replace('static domain_name_servers=', '')
                        continue
                    if 'metric' in line:
                        metric = line.replace('metric ', '')
                        dev_part = False
                        continue

        if metric is None:
            route_out = subprocess.getoutput("ip route")
            route_out = route_out.splitlines()
            for line in route_out:
                if dev in line:
                    metric = line[-4:]

        dev_mask = ni.ifaddresses(f'{dev}')[dev_link][0]['netmask'] if dev_link == 2 else '0.0.0.0'
        if address is None:
            dhcp = True
            address = ni.ifaddresses(f'{dev}')[dev_link][0]['addr'] if dev_link == 2 else '0.0.0.0'
            gateway = ni.gateways()['default'][2][0] if 2 in ni.gateways()['default'] else ''
        else:
            if '/' in address:
                address, dev_mask = self._cidr_to_netmask(address)

        if dns_servers is None:
            with open('/etc/resolv.conf', 'r') as dnsf:
                dns_servers = []
                dns_lines = dnsf.read().splitlines()
                for line in dns_lines:
                    if 'nameserver' in line:
                        dns_servers.append(line.replace('nameserver ', ''))
                        continue
        else:
            dns_servers = dns_servers.split(' ')
        mac = ni.ifaddresses(f'{dev}')[17][0]['addr']
        return {
                'dev': dev,
                'dhcp': dhcp,
                'address': address,
                'netmask': dev_mask,
                'gateway': gateway,
                'dns': dns_servers,
                'mac': mac.upper(),
                "metric": int(metric)
            }

    def _write_network_params(self, dev_params):
        self.networkConfig['priority'] = dev_params['priority']
        self.app.updateConfig()

        priority = dev_params['priority']
        for idx, item in enumerate(dev_params['priority']):
            priority[idx] = item.lower()

        metric_priority = [
            200,
            400,
            600
        ]

        with open('/tmp/tmp_dhcpcd.conf', "w+") as fp:
            text = self._dhcpcd_config_generage()
            fp.write(text)

            for dev in dev_params:
                if 'mobile' in dev:
                    continue
                if 'active_connection' in dev:
                    continue
                if 'priority' in dev:
                    continue
                iface_params = dev_params[dev]
                if iface_params['dev'] is None:
                    continue
                dev_text = f"interface {iface_params['dev']}\n"
                if iface_params['dhcp']:
                    dev_text += f"metric {metric_priority[priority.index(dev.lower())]}\n"
                    dev_text += "\n"
                else:
                    cidr_ip = self.append_cidr_suffix(f"{iface_params['address']}/{iface_params['netmask']}")
                    dev_text += f"static ip_address={cidr_ip}\n"
                    dev_text += f"static routers={iface_params['gateway']}\n"
                    dev_text += f"static domain_name_servers={' '.join(iface_params['dns'])}\n"
                    dev_text += f"metric {metric_priority[priority.index(dev.lower())]}\n"
                    dev_text += "\n"

                fp.write(dev_text)

        system(f"mv /tmp/tmp_dhcpcd.conf {self._dhcpcd_path}")
        # self.app.event_emitter.emit('system:reboot')

    def _dhcpcd_config_generage(self):
        return "hostname\n" \
                "\n" \
               "clientid\n" \
                "\n" \
                "persistent\n" \
                "\n" \
                "option rapid_commit\n"\
                "\n"\
                "option domain_name_servers, domain_name, domain_search, host_name\n"\
                "option classless_static_routes\n"\
                "option interface_mtu\n"\
                "\n"\
                "require dhcp_server_identifier\n"\
                "\n"\
                "slaac private\n"\
                "\n"\
                "profile static_eth0\n"\
                "static ip_address=192.168.99.100/24\n"\
                "static routers=192.168.99.1\n"\
                "static domain_name_servers=192.168.99.1\n"\
                "\n" \
                "interface eth0\n" \
                "fallback static_eth0\n" \
                "\n"
