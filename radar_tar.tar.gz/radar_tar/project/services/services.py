from project.app.mqmessages import MqExchanger, MqChecker, MqObserver
from .config_service import ConfigService
from .deviceService import DeviceService
from .historyService import HistoryService
from .mq_message import MqMessage
from .ntp_service import NtpService
from .serial_service import SerialService
from .user_service import UserService
from .system_service import SystemService

from .save_yml_service import SaveYamlService


class Services:
    def __init__(self, app):
        self._app = app

    @property
    def app(self):
        return self._app

    @property
    def userService(self):
        return UserService(self.app)

    @property
    def serialService(self):
        return SerialService(self.app)

    @property
    def ntpService(self):
        return NtpService(self.app)

    @property
    def mqmessage(self):
        return MqMessage(self.app)

    @property
    def deviceService(self):
        return DeviceService(self.app)

    @property
    def configService(self):
        return ConfigService(self.app)

    @property
    def mqExchanger(self):
        return MqExchanger(self.app)

    @property
    def mqObserver(self):
        return MqObserver(self.app, self.mqExchanger)

    @property
    def mqChecker(self):
        return MqChecker(self.app, self.mqExchanger)

    @property
    def historyService(self):
        return HistoryService(self.app)

    @property
    def systemService(self):
        return SystemService(self.app)

    @property
    def saveYamlService(self):
        return SaveYamlService(self.app)