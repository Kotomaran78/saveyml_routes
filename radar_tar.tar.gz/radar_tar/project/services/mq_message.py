from datetime import datetime
from json import dumps

import pika
from .BaseService import BaseService


class MqMessage(BaseService):
    def __init__(self, app):
        super().__init__(app)
        self._mqconfig = app.config['mq']
        self._connection = None

    def _connect(self):
        self._connection = pika.BlockingConnection(pika.ConnectionParameters(
            host=self._mqconfig['host'],
            credentials=pika.PlainCredentials(self._mqconfig['username'], self._mqconfig['password']
                                              )
        ))
        return self._connection.channel()

    def _close(self):
        self._connection.close()

    def sendmsg(self, keys, msg):
        channel = self._connect()
        channel.basic_publish(exchange=self._mqconfig['topic'], routing_key=keys, body=msg)
        self._close()
        pass

    async def update_serial_cfg(self, interface: str, cfg: dict):
        print(f'config changed, send to mq')
        keys = 'serial.serial.command'
        msg = {
            'command': "update",
            "opts": {
                "interfaces": interface,
                'timestamp': datetime.now().timestamp(),
                **cfg
            }
        }
        channel = self._connect()
        channel.basic_publish(exchange=self._mqconfig['topic'], routing_key=keys, body=dumps(msg))
        self._close()

    async def update_device_cfg(self, interface: str, cfg: dict):
        print('restart device service')

    async def set_relay_status(self, gpo_name, value):
        keys = 'gpio.gpio.command'
        msg = {
            'command': "set",
            "opts": {
                "gpo": gpo_name,
                'value': value,
            }
        }
        channel = self._connect()
        channel.basic_publish(exchange=self._mqconfig['topic'], routing_key=keys, body=dumps(msg))
        self._close()