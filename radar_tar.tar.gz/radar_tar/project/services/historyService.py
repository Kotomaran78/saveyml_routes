import csv
from datetime import datetime, timedelta, timezone
from os import path

from .BaseService import BaseService
from project.db import device, history
from project.web.errors import DeviceNotFound
from decimal import Decimal


class HistoryService(BaseService):
    def __init__(self, app):
        print(app)
        super().__init__(app)

    async def get_history(self, data):
        query = device.select().where(device.c.id == int(data['device']))
        query_result = await self.db.fetch_one(query)
        if query_result is None:
            raise DeviceNotFound()

        device_obj = dict(query_result.items())

        if '1-wire' in device_obj['device']:
            device_name = 'ds18b20@' + str(device_obj['id'])
        else:
            device_name = str(device_obj['device']) + '@' + str(device_obj['id'])

        date_from = datetime.strptime(data['dates'][0], "%Y-%m-%d")
        date_to = datetime.strptime(data['dates'][1], "%Y-%m-%d")

        date_to = date_to + timedelta(hours=23, minutes=59, seconds=59)

        query = history.select().where(
            history.c.device == str(device_name)
        ).where(
            history.c.read_at.between(
                date_from, date_to
            )
        ).order_by(history.c.created_at.asc())
        history_rows = await self.db.fetch_all(query)
        history_dicts = ([(dict(row.items())) for row in history_rows])
        registers = self.app.registers206
        if 'mercury_236' in device_name:
            registers = self.app.registers236
        if 'ds18b20' in device_name:
            registers = self.app.registersOneWire
        if 'ganjubus' in device_name:
            registers = self.app.registersGanjubus

        values = []
        labels = []
        chart_data = []
        for hist_data in history_dicts:
            if hist_data['value'] is not None and data['channel'] in hist_data['value']:
                value_format = '{:.' + str(registers[data['channel']]['scale'] * (-1) + 2 ) + '}'
                db_value = value_format.format(float(hist_data['value'][data['channel']]))
                values.append(db_value)

            if hist_data['read_at'] is not None:
                labels.append(hist_data['read_at'].timestamp())

            chart_data.append([int(hist_data['read_at'].timestamp() * 1000), float(db_value)])

        return {"data": chart_data}

    async def history_to_csv(self, data):
        query = device.select().where(device.c.id == int(data['device']))
        query_result = await self.db.fetch_one(query)

        if query_result is None:
            raise DeviceNotFound()

        device_obj = dict(query_result.items())

        if '1-wire' in device_obj['device']:
            device_name = 'ds18b20@' + str(device_obj['id'])
        else:
            device_name = str(device_obj['device']) + '@' + str(device_obj['id'])

        date_from = datetime.strptime(data['dates'][0], "%Y-%m-%d")
        date_to = datetime.strptime(data['dates'][1], "%Y-%m-%d")

        date_to = date_to + timedelta(hours=23, minutes=59, seconds=59)
        query = history.select().where(
            history.c.device == str(device_name)
        ).where(
            history.c.read_at.between(
                date_from, date_to
            )
        ).order_by(history.c.created_at.asc())
        history_rows = await self.db.fetch_all(query)
        if history_rows is None:
            return False
        history_dicts = ([(dict(row.items())) for row in history_rows])

        registers = self.app.registers206
        if 'mercury_236' in device_name:
            registers = self.app.registers236
        if 'ds18b20' in device_name:
            registers = self.app.registersOneWire
        filename = f"{device_obj['topic']}_{data['channel']}_{data['dates'][0]}_{data['dates'][1]}.csv"
        if data['dates'][0] == data['dates'][1]:
            filename = f"{device_obj['topic']}_{data['channel']}_{data['dates'][0]}.csv"

        filename = filename.replace('/', '_')

        with open(path.join(self.app.history_folder, filename), mode='w') as csv_file:

            fieldnames = ['Time','Device name',f"{data['channel']}, {registers[data['channel']]['unit']}"]
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames, delimiter=";")
            writer.writeheader()

            for hisrow in history_dicts:
                if hisrow['value'] is None or data['channel'] not in hisrow['value']:
                    continue

                if 'read_at' in hisrow and hisrow['read_at'] is not None:
                    date = hisrow['read_at'].astimezone().strftime("%m/%d/%Y %H:%M:%S")

                value_format = '{:.' + str(registers[data['channel']]['scale'] * (-1) + 2) + '}'
                formatted_value = value_format.format(float(hisrow['value'][data['channel']]))

                writer.writerow(
                    {
                        "Time": date,
                        "Device name": device_obj['topic'],
                        f"{data['channel']}, {registers[data['channel']]['unit']}": formatted_value
                    }
                )

            return filename
