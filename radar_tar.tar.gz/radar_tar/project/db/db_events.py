
def load_events(app, sanic):
    @sanic.listener('after_server_start')
    async def connect_to_db(*args, **kwargs):
        print('after_start load db')
        try:
            await sanic.db.connect()
        except:
            pass

    @sanic.listener('after_server_stop')
    async def disconnect_from_db(*args, **kwargs):
        await sanic.db.disconnect()
