import sqlalchemy
from sqlalchemy.sql import func

metadata = sqlalchemy.MetaData()

users = sqlalchemy.Table(
    'user',
    metadata,
    sqlalchemy.Column('id', sqlalchemy.Integer, primary_key=True),
    sqlalchemy.Column('username', sqlalchemy.String(length=255)),
    sqlalchemy.Column('password', sqlalchemy.LargeBinary()),
    sqlalchemy.Column('refresh_token', sqlalchemy.String(length=255))
)

tokens = sqlalchemy.Table(
    'access_tokens',
    metadata,
    sqlalchemy.Column('id', sqlalchemy.Integer, primary_key=True),
    sqlalchemy.Column('token', sqlalchemy.String(length=255)),
    sqlalchemy.Column('user_id', sqlalchemy.Integer, ),
    sqlalchemy.ForeignKeyConstraint(['user_id'], ['user.id'], name='access_tokens_user_id_fk'),
)

status = sqlalchemy.Table(
    'status',
    metadata,
    sqlalchemy.Column('id', sqlalchemy.Integer, primary_key=True),
    sqlalchemy.Column('status', sqlalchemy.String(length=255)),
    sqlalchemy.Column('config', sqlalchemy.JSON),
    sqlalchemy.Column('timestamp', sqlalchemy.TIMESTAMP)
)

device = sqlalchemy.Table(
    'device',
    metadata,
    sqlalchemy.Column('id', sqlalchemy.Integer, primary_key=True),
    sqlalchemy.Column('device', sqlalchemy.String(length=255)),
    sqlalchemy.Column('slave_id', sqlalchemy.String(length=255)),
    sqlalchemy.Column('address', sqlalchemy.String(length=255)),
    sqlalchemy.Column('topic', sqlalchemy.String(length=255)),
    sqlalchemy.Column('port', sqlalchemy.String(length=255)),
    sqlalchemy.Column('interval', sqlalchemy.Integer),
    sqlalchemy.Column('history', sqlalchemy.Integer),
    sqlalchemy.Column('registers', sqlalchemy.JSON),
    sqlalchemy.Column('password', sqlalchemy.String(length=255))
)

history = sqlalchemy.Table(
    'history',
    metadata,
    sqlalchemy.Column('id', sqlalchemy.Integer, primary_key=True),
    sqlalchemy.Column('device', sqlalchemy.String(length=255)),
    sqlalchemy.Column('value', sqlalchemy.JSON),
    sqlalchemy.Column('created_at', sqlalchemy.TIMESTAMP, default=func.now()),
    sqlalchemy.Column('read_at', sqlalchemy.TIMESTAMP)
)

to_dict = lambda r: {k: v for k, v in r.items()}
