from databases import Database
from project.db import load_events


class DB:
    def __init__(self, app):
        self._app = app
        self._sanic = app.web.sanic

    @property
    def app(self):
        return self._app

    @property
    def sanic(self):
        return self._sanic

    def setup_database(self):
        self.sanic.db = Database(self.sanic.config.DB_URL)
        load_events(self.app, self.sanic)
        return self.sanic.db
