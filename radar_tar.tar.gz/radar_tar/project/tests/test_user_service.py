import pytest
from ..app import App
import json
from project.db.tables import users


@pytest.fixture
def app():
    app = App(test_run=True)
    app.initialize()
    sanic = app.web.sanic

    yield sanic


@pytest.fixture
def test_cli(loop, app, sanic_client):
    return loop.run_until_complete(sanic_client(app))

@pytest.fixture
async def auth_headers(test_cli):
    data = {'username': "admin", "password": "admin"}
    resp = await test_cli.post('/auth', data=json.dumps(data))
    resp_json = await resp.json()
    headers = {'Authorization': f"Bearer {resp_json['access_token']}"}

    yield headers

"""
TESTS
"""


async def test_get_users(test_cli, auth_headers):
    """
    GET users
    """
    resp = await test_cli.get('/users', headers=auth_headers)
    assert resp.status == 200
    resp_json = await resp.json()
    assert {'id': 1, 'username': 'admin'} in resp_json
    assert type(resp_json) == list

async def test_unauth_get_users(test_cli):
    """
    GET users
    """
    resp = await test_cli.get('/users')
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'


async def test_get_admin_user(test_cli, auth_headers):
    """
    GET first user, must be admin
    """
    resp = await test_cli.get('/users/1', headers=auth_headers)
    assert resp.status == 200
    resp_json = await resp.json()
    assert resp_json == {'id': 1, 'username': 'admin'}

async def test_unauth_get_admin_user(test_cli):
    """
    GET first user, must be admin
    """
    resp = await test_cli.get('/users/1')
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'

async def test_get_fail_user(test_cli, auth_headers):
    """
    GET user not in db
    """
    resp = await test_cli.get('/users/111434354', headers=auth_headers)
    assert resp.status == 400
    resp_json = await resp.json()
    assert resp_json['error'] == 'UserNotFound'

async def test_unauth_get_fail_user(test_cli):
    """
    GET user not in db
    """
    resp = await test_cli.get('/users/111434354')
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'

async def test_fail_delete_user(test_cli, auth_headers):
    """
    Delete user fail
    """
    resp = await test_cli.delete('/users/111434354', headers=auth_headers)
    assert resp.status == 400
    resp_json = await resp.json()
    assert resp_json['error'] == 'UserNotFound'

async def test_unauth_fail_delete_user(test_cli):
    """
    Delete user fail
    """
    resp = await test_cli.delete('/users/111434354')
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'

async def test_unauth_create_user(test_cli):
    """
    Post create user
    """
    data = {"username": "test_user", "password": "test_password"}
    resp = await test_cli.post('/users', data=json.dumps(data))
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'

async def test_create_user(test_cli, auth_headers):
    """
    Post create user
    """
    data = {"username": "test_user", "password": "test_password"}
    resp = await test_cli.post('/users', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 200
    resp_json = await resp.json()
    assert resp_json['username'] == 'test_user'

async def test_fail_create_user(test_cli, auth_headers):
    """
    Post fail create user
    """
    data = {"username": "test_user"}
    resp = await test_cli.post('/users', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 400
    resp_json = await resp.json()
    assert resp_json['error'] == 'ValidationError'


async def test_delete_user(test_cli, auth_headers):
    query = users.select().with_only_columns([users.c.id, users.c.username]).where(users.c.username == 'test_user')
    user = await test_cli.app.db.fetch_one(query)
    test_user = dict(user.items())

    user_id = str(test_user['id'])
    """
    Delete user
    """
    resp = await test_cli.delete('/users' + f"/{user_id}", headers=auth_headers)
    assert resp.status == 200
    resp_json = await resp.json()
    assert resp_json == True