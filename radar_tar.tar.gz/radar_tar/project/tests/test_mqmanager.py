# import pytest
# from datetime import datetime
# from project.db.tables import device, history
# from ..app import App
#
#
# @pytest.fixture
# def app():
#     main_app = App(test_run=True)
#     main_app.initialize()
#     main_app.web._init_mqobserver()
#
#     yield main_app
#
# @pytest.fixture
# def sanic(app):
#     sanic = app.web.sanic
#
#     yield sanic
#
#
# @pytest.fixture
# def test_cli(loop, sanic, sanic_client):
#     return loop.run_until_complete(sanic_client(sanic))
#
# async def test_mqmanager(app, test_cli):
#     assert app.service.mqChecker.status is None
#
#     msg = {
#         "mercuri_206@1222222": {
#             "c_current": 0.050000000000000003,
#             "c_power": 12,
#             "c_voltage": 239.5,
#             "count1": 0.97999999999999998,
#             "count2": 0.65000000000000002
#         },
#         "timestamp": int(datetime.now().timestamp())
#     }
#     await app.service.mqObserver.update(msg)
#     await app.service.mqChecker.set_status(msg)
#
#     query = history.select().where(history.c.device == 'mercuri_206@1222222')
#     device_history_db = await test_cli.app.db.fetch_one(query)
#     assert device_history_db is not None
#
#     device_history = dict(device_history_db.items())
#     assert device_history['read_at'].timestamp() == msg['timestamp']