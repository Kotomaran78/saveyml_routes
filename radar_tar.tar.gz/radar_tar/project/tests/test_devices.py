import pytest
from ..app import App
import json
from project.db.tables import device


@pytest.fixture
def app():
    app = App(test_run=True)
    app.initialize()
    sanic = app.web.sanic

    yield sanic


@pytest.fixture
def test_cli(loop, app, sanic_client):
    return loop.run_until_complete(sanic_client(app))


@pytest.fixture
async def auth_headers(test_cli):
    data = {'username': "admin", "password": "admin"}
    resp = await test_cli.post('/auth', data=json.dumps(data))
    resp_json = await resp.json()
    headers = {'Authorization': f"Bearer {resp_json['access_token']}"}

    yield headers

"""
TESTS
"""


async def test_get_unauth_devices(test_cli):
    """
    GET current devices list
    must be empty
    """
    resp = await test_cli.get('/api/devices')
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'


async def test_get_devices(test_cli, auth_headers):
    """
    GET current devices list
    must be empty
    """
    resp = await test_cli.get('/api/devices', headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert type(resp_json) == list


async def test_get_unauth_supported_devices(test_cli):
    """
    GET supported devices
    must be only mercurys and 1-wire
    """
    resp = await test_cli.get('/api/devices/supported')
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'


async def test_get_supported_devices(test_cli, auth_headers):
    """
    GET supported devices
    must be only mercurys and 1-wire
    """
    resp = await test_cli.get('/api/devices/supported', headers=auth_headers)
    assert resp.status == 200
    resp_json = await resp.json()
    assert resp_json == [
            {
                "text": "1-wire",
                "value": "1-wire"
            },
            {
                "text": "mercury_206",
                "value": "mercury_206"
            },
            {
                "text": "mercury_236",
                "value": "mercury_236"
            }
        ]


async def test_get_unauth_mercury_206_registers(test_cli):
    """
    GET mercury_206 registers
    """
    resp = await test_cli.get('/api/devices/mercury_206/registers')
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'


async def test_get_mercury_206_registers(test_cli, auth_headers):
    """
    GET mercury_206 registers
    """
    resp = await test_cli.get('/api/devices/mercury_206/registers', headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'


async def test_get_unauth_mercury_236_registers(test_cli):
    """
    GET mercury_236 registers
    """
    resp = await test_cli.get('/api/devices/mercury_236/registers')
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'


async def test_get_mercury_236_registers(test_cli, auth_headers):
    """
    GET mercury_236 registers
    """
    resp = await test_cli.get('/api/devices/mercury_236/registers', headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'


async def test_get_unauth_1_wire_registers(test_cli):
    """
    GET 1-wire registers
    """
    resp = await test_cli.get('/api/devices/1-wire/registers')
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'


async def test_get_1_wire_registers(test_cli, auth_headers):
    """
    GET 1-wire registers
    """
    resp = await test_cli.get('/api/devices/1-wire/registers', headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'


async def test_get_unauth_1_wire_connected_devices(test_cli):
    """
    GET connected 1-wire
    must be list with 2 device
    """
    resp = await test_cli.get('/api/devices/1-wire/connected')
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'


async def test_get_1_wire_connected_devices(test_cli, auth_headers):
    """
    GET connected 1-wire
    must be list with 2 device
    """
    resp = await test_cli.get('/api/devices/1-wire/connected', headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert resp_json == ['28-00009fa01e4', '28-00009f7d59c']


async def test_post_unauth_create_mercury_206_device(test_cli):
    """
    POST create new mercury_206 device
    :param test_cli:
    :return:
    """
    data = {
        "device": {
            "slave_id": "1234323432",
            "topic": "/device/test_mercury_206",
            "device": "mercury_206",
            "interval": 2000,
            "port": "RS-485 #1",
            "history": 60
        },
        "registers": [
            "timecor",
            "seasontime_flag",
            "menerg",
            "c_power"
        ]
    }
    resp = await test_cli.post('/api/devices/mercury_206/create', data=json.dumps(data))
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'


async def test_post_create_mercury_206_device(test_cli,auth_headers):
    """
    POST create new mercury_206 device
    :param test_cli:
    :return:
    """
    data = {
        "device": {
            "slave_id": "1234323432",
            "topic": "/device/test_mercury_206",
            "device": "mercury_206",
            "interval": 2000,
            "port": "RS-485 #1",
            "history": 60
        },
        "registers": [
            "timecor",
            "seasontime_flag",
            "menerg",
            "c_power"
        ]
    }
    resp = await test_cli.post('/api/devices/mercury_206/create', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert type(resp_json) == int


async def test_post_create_duplicate_mercury_206_device(test_cli, auth_headers):
    """
    POST create duplicate mercury_206 device
    :param test_cli:
    :return:
    """
    data = {
        "device": {
            "slave_id": "1234323432",
            "topic": "/device/test_mercury_206",
            "device": "mercury_206",
            "interval": 2000,
            "port": "RS-485 #1",
            "history": 60
        },
        "registers": [
            "timecor",
            "seasontime_flag",
            "menerg",
            "c_power"
        ]
    }
    resp = await test_cli.post('/api/devices/mercury_206/create', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 400
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert resp_json['error'] == "DuplicateDevice"


async def test_post_fail_create_mercury_206_device(test_cli, auth_headers):
    """
    POST fail validation create new mercury_206 device
    :param test_cli:
    :return:
    """
    data = {
        "device": {
            "slave_id": "1234323432",
            "topic": "/device/test_mercury_206",
            "device": "mercury_206",
            "interval": 2000
        },
        "registers": [
            "timecor",
            "seasontime_flag",
            "menerg",
            "c_power"
        ]
    }
    resp = await test_cli.post('/api/devices/mercury_206/create', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 400
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert resp_json['error'] == "ValidationError"


async def test_update_unauth_mercury_206_device(test_cli):
    """
    PUT update mercury_206 device
    :param test_cli:
    :return:
    """
    db_device_query = device.select().where(device.c.device == 'mercury_206').where(device.c.slave_id == "1234323432")
    db_device = await test_cli.app.db.fetch_one(db_device_query)
    db_device = dict(db_device.items())

    data = {
        "device": {
            "slave_id": "123432343232",
            "topic": "/device/test_mercury_206_update",
            "device": "mercury_206",
            "interval": 4000,
            "port": "RS-485 #1",
            "history": 15
        },
        "registers": [
            "timecor",
            "seasontime_flag",
            "menerg",
            "c_power"
        ]
    }
    resp = await test_cli.put('/api/devices/mercury_206/' + str(db_device['id']), data=json.dumps(data))
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'


async def test_update_mercury_206_device(test_cli, auth_headers):
    """
    PUT update mercury_206 device
    :param test_cli:
    :return:
    """
    db_device_query = device.select().where(device.c.device == 'mercury_206').where(device.c.slave_id == "1234323432")
    db_device = await test_cli.app.db.fetch_one(db_device_query)
    db_device = dict(db_device.items())

    data = {
        "device": {
            "slave_id": "123432343232",
            "topic": "/device/test_mercury_206_update",
            "device": "mercury_206",
            "interval": 4000,
            "port": "RS-485 #1",
            "history": 15
        },
        "registers": [
            "timecor",
            "seasontime_flag",
            "menerg",
            "c_power"
        ]
    }
    resp = await test_cli.put('/api/devices/mercury_206/' + str(db_device['id']), data=json.dumps(data), headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert data['device']['slave_id'] == resp_json['slave_id']
    assert data['device']['topic'] == resp_json['topic']
    assert data['device']['interval'] == resp_json['interval']
    assert data['device']['history'] == resp_json['history']


async def test_fail_update_mercury_206_device(test_cli, auth_headers):
    """
    PUT fail validation update mercury_206 device
    :param test_cli:
    :return:
    """
    db_device_query = device.select().where(device.c.device == 'mercury_206').where(device.c.slave_id == "123432343232")
    db_device = await test_cli.app.db.fetch_one(db_device_query)
    db_device = dict(db_device.items())

    data = {
        "device": {
            "slave_id": "123432343232",
            "topic": "/device/test_mercury_206_update",
            "device": "mercury_206",
            "interval": 4000,
            "port": "RS-485 #1",
        }
    }
    resp = await test_cli.put('/api/devices/mercury_206/' + str(db_device['id']), data=json.dumps(data), headers=auth_headers)
    assert resp.status == 400
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert resp_json['error'] == 'ValidationError'


async def test_fail_not_found_update_mercury_206_device(test_cli, auth_headers):
    """
    PUT fail not found update mercury_206 device
    :param test_cli:
    :return:
    """
    data = {
        "device": {
            "slave_id": "123432343232",
            "topic": "/device/test_mercury_206_update",
            "device": "mercury_206",
            "interval": 4000,
            "port": "RS-485 #1",
            "history": 15
        },
        "registers": [
            "timecor",
            "seasontime_flag",
            "menerg",
            "c_power"
        ]
    }
    resp = await test_cli.put('/api/devices/mercury_206/111', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 400
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert resp_json['error'] == 'DeviceNotFound'


async def test_delete_unauth_mercury_206_device(test_cli):
    """
    DELETE mercury_206 device
    :param test_cli:
    :return:
    """
    db_device_query = device.select().where(device.c.device == 'mercury_206').where(device.c.slave_id == "123432343232")
    db_device = await test_cli.app.db.fetch_one(db_device_query)
    db_device = dict(db_device.items())


    resp = await test_cli.delete('/api/devices/mercury_206/' + str(db_device['id']))
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'


async def test_delete_mercury_206_device(test_cli, auth_headers):
    """
    DELETE mercury_206 device
    :param test_cli:
    :return:
    """
    db_device_query = device.select().where(device.c.device == 'mercury_206').where(device.c.slave_id == "123432343232")
    db_device = await test_cli.app.db.fetch_one(db_device_query)
    db_device = dict(db_device.items())


    resp = await test_cli.delete('/api/devices/mercury_206/' + str(db_device['id']), headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert resp_json == True


async def test_fail_delete_mercury_206_device(test_cli, auth_headers):
    """
    DELETE fail mercury_206 device
    :param test_cli:
    :return:
    """
    resp = await test_cli.delete('/api/devices/mercury_206/1', headers=auth_headers)
    assert resp.status == 400
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert resp_json['error'] == 'DeviceNotFound'


async def test_post_create_mercury_236_device(test_cli,auth_headers):
    """
    POST create new mercury_236 device
    :param test_cli:
    :return:
    """
    data = {
        "device": {
            "slave_id": "6666666666",
            "topic": "/device/test_mercury_236",
            "device": "mercury_236",
            "interval": 2000,
            "port": "RS-485 #1",
            "history": 60,
            "password": "1234567"
        },
        "registers": [
            "timecor",
            "seasontime_flag",
            "menerg",
            "c_power"
        ]
    }
    resp = await test_cli.post('/api/devices/mercury_236/create', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert type(resp_json) == int


async def test_fail_post_create_mercury_236_device(test_cli, auth_headers):
    """
    POST fail validation create new mercury_236 device
    :param test_cli:
    :return:
    """
    data = {
        "device": {
            "slave_id": "6666666666",
            "topic": "/device/test_mercury_236",
            "device": "mercury_236",
            "interval": 2000,
            "port": "RS-485 #1",
        },
        "registers": [
            "timecor",
            "seasontime_flag",
            "menerg",
            "c_power"
        ]
    }
    resp = await test_cli.post('/api/devices/mercury_236/create', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 400
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert resp_json['error'] == 'ValidationError'


async def test_update_mercury_236_device(test_cli, auth_headers):
    """
    PUT update mercury_236 device
    :param test_cli:
    :return:
    """
    db_device_query = device.select().where(device.c.device == 'mercury_236').where(device.c.slave_id == "6666666666")
    db_device = await test_cli.app.db.fetch_one(db_device_query)
    db_device = dict(db_device.items())

    data = {
        "device": {
            "slave_id": "66666666661",
            "topic": "/device/test_mercury_236_update",
            "device": "mercury_236",
            "interval": 4000,
            "port": "RS-485 #1",
            "history": 15,
            "password": "123456789"
        },
        "registers": [
            "timecor",
            "seasontime_flag",
            "menerg",
            "c_power"
        ]
    }
    resp = await test_cli.put('/api/devices/mercury_236/' + str(db_device['id']), data=json.dumps(data), headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert data['device']['slave_id'] == resp_json['slave_id']
    assert data['device']['topic'] == resp_json['topic']
    assert data['device']['interval'] == resp_json['interval']
    assert data['device']['history'] == resp_json['history']


async def test_fail_update_mercury_236_device(test_cli, auth_headers):
    """
    PUT fail validation update mercury_236 device
    :param test_cli:
    :return:
    """
    db_device_query = device.select().where(device.c.device == 'mercury_236').where(device.c.slave_id == "66666666661")
    db_device = await test_cli.app.db.fetch_one(db_device_query)
    db_device = dict(db_device.items())

    data = {
        "device": {
            "slave_id": "66666666661",
            "topic": "/device/test_mercury_236_update",
            "device": "mercury_236",
            "interval": 4000,
            "port": "RS-485 #1",
        },
        "registers": [
            "timecor",
            "seasontime_flag",
            "menerg",
            "c_power"
        ]
    }
    resp = await test_cli.put('/api/devices/mercury_236/' + str(db_device['id']), data=json.dumps(data), headers=auth_headers)
    assert resp.status == 400
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert resp_json['error'] == "ValidationError"


async def test_delete_mercury_236_device(test_cli, auth_headers):
    """
    DELETE mercury_236 device
    :param test_cli:
    :return:
    """
    db_device_query = device.select().where(device.c.device == 'mercury_236').where(device.c.slave_id == "66666666661")
    db_device = await test_cli.app.db.fetch_one(db_device_query)
    db_device = dict(db_device.items())


    resp = await test_cli.delete('/api/devices/mercury_236/' + str(db_device['id']), headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert resp_json == True


async def test_post_create_1_wire_device(test_cli, auth_headers):
    """
    POST create new 1-wire device
    :param test_cli:
    :return:
    """
    data = {
        "device": {
            "device": "1-wire",
            "address": "123-45677890",
            "topic": "/device/test_1-wire",
            "port": "1-Wire",
            "interval": 2000,
            "history": 15
        },
        "registers": [
            "timecor",
            "seasontime_flag",
            "menerg",
            "c_power"
        ]
    }
    resp = await test_cli.post('/api/devices/1-wire/create', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert type(resp_json) == int


async def test_update_1_wire_device(test_cli, auth_headers):
    """
    PUT update 1-wire device
    :param test_cli:
    :return:
    """
    db_device_query = device.select().where(device.c.device == '1-wire').where(device.c.address == '123-45677890')
    db_device = await test_cli.app.db.fetch_one(db_device_query)
    db_device = dict(db_device.items())

    data = {
        "device": {
            "device": "1-wire",
            "address": "123-456778901",
            "topic": "/device/test_1-wire",
            "port": "1-Wire",
            "interval": 2000,
            "history": 15
        },
        "registers": [
            "timecor",
            "seasontime_flag",
            "menerg",
            "c_power"
        ]
    }
    resp = await test_cli.put('/api/devices/1-wire/' + str(db_device['id']), data=json.dumps(data), headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert data['device']['address'] == resp_json['address']
    assert data['device']['topic'] == resp_json['topic']
    assert data['device']['interval'] == resp_json['interval']
    assert data['device']['history'] == resp_json['history']


async def test_fail_update_1_wire_device(test_cli, auth_headers):
    """
    PUT fail validation update 1-wire device
    :param test_cli:
    :return:
    """
    db_device_query = device.select().where(device.c.device == '1-wire').where(device.c.address == "123-456778901")
    db_device = await test_cli.app.db.fetch_one(db_device_query)
    db_device = dict(db_device.items())

    data = {
        "device": {
            "device": "1-wire",
            "address": "123-456778901",
            "topic": "/device/test_1-wire",
            "port": "1-Wire",
        },
        "registers": [
            "timecor",
            "seasontime_flag",
            "menerg",
            "c_power"
        ]
    }
    resp = await test_cli.put('/api/devices/1-wire/' + str(db_device['id']), data=json.dumps(data), headers=auth_headers)
    assert resp.status == 400
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert resp_json['error'] == "ValidationError"


async def test_delete_1_wire_device(test_cli, auth_headers):
    """
    DELETE 1-wire device
    :param test_cli:
    :return:
    """
    db_device_query = device.select().where(device.c.device == '1-wire').where(device.c.address == "123-456778901")
    db_device = await test_cli.app.db.fetch_one(db_device_query)
    db_device = dict(db_device.items())


    resp = await test_cli.delete('/api/devices/1-wire/' + str(db_device['id']), headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert resp_json == True