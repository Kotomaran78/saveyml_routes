import pytest
from ..app import App
import json


@pytest.fixture
def app():
    app = App(test_run=True)
    app.initialize()
    sanic = app.web.sanic

    yield sanic


@pytest.fixture
def test_cli(loop, app, sanic_client):
    return loop.run_until_complete(sanic_client(app))

@pytest.fixture
async def auth_headers(test_cli):
    data = {'username': "admin", "password": "admin"}
    resp = await test_cli.post('/auth', data=json.dumps(data))
    resp_json = await resp.json()
    headers = {'Authorization': f"Bearer {resp_json['access_token']}"}

    yield headers

"""
TESTS
"""


async def test_admin_auth(test_cli):
    """
    POST admin auth
    """
    data = {'username': "admin", "password": "admin"}
    resp = await test_cli.post('/auth', data=json.dumps(data))
    assert resp.status == 200
    resp_json = await resp.json()
    assert 'access_token' in resp_json
    assert 'refresh_token' in resp_json


async def test_fail_admin_auth(test_cli):
    """
    POST fail admin auth
    """
    data = {'username': "admin"}
    resp = await test_cli.post('/auth', data=json.dumps(data))
    assert resp.status == 401
    resp_json = await resp.json()
    assert 'error' in resp_json
    assert 'message' in resp_json
    assert resp_json['error'] == 'AuthenticationFailed'
    assert resp_json['message'] == 'Missing username or password.'


async def test_auth_get_self(test_cli):
    """
    GET get self
    """
    data = {'username': "admin", "password": "admin"}
    resp = await test_cli.post('/auth', data=json.dumps(data))
    assert resp.status == 200
    resp_json = await resp.json()

    headers = {'Authorization': f"Bearer {resp_json['access_token']}"}
    resp = await test_cli.get('/auth/me', headers=headers)

    assert resp.status == 200
    resp_json = await resp.json()
    assert resp_json['me']['username'] == 'admin'


async def test_auth_refresh_token(test_cli):
    """
    POST refresh token
    """
    data = {'username': "admin", "password": "admin"}
    resp = await test_cli.post('/auth', data=json.dumps(data))
    assert resp.status == 200
    resp_json = await resp.json()

    refresh_token = {'refresh_token': resp_json['refresh_token']}
    headers = {'Authorization': f"Bearer {resp_json['access_token']}"}
    resp = await test_cli.post('/auth/refresh', headers=headers, data=json.dumps(refresh_token))
    assert resp.status == 200
    resp_json = await resp.json()
    assert 'access_token' in resp_json


async def test_auth_fail_reset_password(test_cli, auth_headers):
    """
    POST reset password
    """
    data = {'current': "admin2", "new_password": "admin1"}
    resp = await test_cli.put('/users', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 401
    resp_json = await resp.json()
    assert 'error' in resp_json
    assert 'message' in resp_json
    assert resp_json['error'] == 'AuthenticationFailed'
    assert resp_json['message'] == 'Password is incorrect.'


async def test_auth_fail_validation_reset_password(test_cli, auth_headers):
    """
    POST reset password
    """
    data = {'current': "admin"}
    resp = await test_cli.put('/users', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 400
    resp_json = await resp.json()
    assert resp_json['error'] == 'ValidationError'


async def test_auth_reset_password(test_cli, auth_headers):
    """
    POST reset password
    """
    data = {'current': "admin", "new_password": "admin1"}
    resp = await test_cli.put('/users', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 200
    resp_json = await resp.json()
    assert resp_json == True

    data = {'current': "admin1", "new_password": "admin"}
    resp = await test_cli.put('/users', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 200
    resp_json = await resp.json()
    assert resp_json == True
