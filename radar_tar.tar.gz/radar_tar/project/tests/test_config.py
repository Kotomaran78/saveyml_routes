import pytest
import os
import json
from ..app import App
from project.config.config import config, saveConfig
from yaml import safe_load, safe_dump

@pytest.fixture
def app():
    main_app = App(test_run=True)
    main_app.initialize()

    yield main_app

@pytest.fixture
def fnconfig(app):
    fnconfig = config(app, True)

    yield fnconfig


async def test_load_config(fnconfig):
    with open(os.path.join(os.path.dirname(__file__), 'config.test.yml'), 'r', encoding='utf-8') as c:
        test_config = safe_load(c.read())

    assert test_config == fnconfig
    assert test_config['ntp_config'] == fnconfig['ntp_config']

async def test_save_config(app, fnconfig):
    fnconfig['ntp_config'] = '/etc/ntp.conf'

    save_resp = saveConfig(app, fnconfig, True)

    assert save_resp == True

    with open(os.path.join(os.path.dirname(__file__), 'config.test.yml'), 'r', encoding='utf-8') as c:
        updated_config = safe_load(c.read())

    assert updated_config['ntp_config'] == '/etc/ntp.conf'

    fnconfig['ntp_config'] = 'tests/ntp.conf'

    save_resp = saveConfig(app, fnconfig, True)

    assert save_resp == True