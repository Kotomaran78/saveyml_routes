import pytest
import json
from ..app import App


@pytest.fixture
def app():
    app = App(test_run=True)
    app.initialize()
    sanic = app.web.sanic

    yield sanic


@pytest.fixture
def test_cli(loop, app, sanic_client):
    return loop.run_until_complete(sanic_client(app))


@pytest.fixture
async def auth_headers(test_cli):
    data = {'username': "admin", "password": "admin"}
    resp = await test_cli.post('/auth', data=json.dumps(data))
    resp_json = await resp.json()
    headers = {'Authorization': f"Bearer {resp_json['access_token']}"}

    yield headers

"""
TESTS
"""

async def test_unauth_post_ping(test_cli):
    """
    POST ping
    """
    data = {"pingParams":{"host":"google.ru","count":4,"size":64,"timeout":1}}
    resp = await test_cli.post('/api/ping', data=json.dumps(data))
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'

async def test_post_ping(test_cli, auth_headers):
    """
    POST ping
    """
    data = {"pingParams":{"host":"google.ru","count":4,"size":64,"timeout":1}}
    resp = await test_cli.post('/api/ping', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'

async def test_post_ping_400_error(test_cli, auth_headers):
    """
    POST ping error
    """
    data = {"pingParams":{"host":"google.ru"}}
    resp = await test_cli.post('/api/ping', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 400
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert "ValidationError" == resp_json['error']

async def test_unauth_post_ntp(test_cli):
    """
    POST ntp
    """
    data = {
        "ntps":
            {
                "server1": "4.pool.ntp.org",
                "server2": "5.pool.ntp.org",
                "server3": "6.pool.ntp.org",
                "server4": "7.pool.ntp.org"
            }
    }
    resp = await test_cli.post('/api/ntp', data=json.dumps(data))
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'

async def test_post_ntp(test_cli, auth_headers):
    """
    POST ntp
    """
    data = {
        "ntps":
            {
                "server1": "4.pool.ntp.org",
                "server2": "5.pool.ntp.org",
                "server3": "6.pool.ntp.org",
                "server4": "7.pool.ntp.org"
            }
    }
    resp = await test_cli.post('/api/ntp', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert resp_json == True

async def test_post_ntp_400_wrong_server(test_cli, auth_headers):
    """
    POST ntp error
    """
    data = {
        "ntps":
            {
                "server2": "5.pool.ntp.org"
            }
    }
    resp = await test_cli.post('/api/ntp', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 400
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert "ValidationError" == resp_json['error']

async def test_post_ntp_one(test_cli, auth_headers):
    """
    POST ntp one server
    """
    data = {
        "ntps":
            {
                "server1": "4.pool.ntp.org"
            }
    }
    resp = await test_cli.post('/api/ntp', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert resp_json == True

async def test_post_ntp_400_error(test_cli, auth_headers):
    """
    POST ntp error
    """
    data = {
        "ntps":
            {
            }
    }
    resp = await test_cli.post('/api/ntp', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 400
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert "ValidationError" == resp_json['error']

async def test_unauth_post_trace(test_cli):
    """
    POST trace
    """
    data = {"traceParams": {"host": "google.ru", "ttl": 20}}
    resp = await test_cli.post('/api/trace', data=json.dumps(data))
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'

async def test_post_trace(test_cli, auth_headers):
    """
    POST trace
    """
    data = {"traceParams": {"host": "google.ru", "ttl": 20}}
    resp = await test_cli.post('/api/trace', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'

async def test_post_trace_400_error(test_cli, auth_headers):
    """
    POST trace error
    """
    data = {"traceParams": {"host": "google.ru"}}
    resp = await test_cli.post('/api/trace', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 400
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert "ValidationError" == resp_json['error']

