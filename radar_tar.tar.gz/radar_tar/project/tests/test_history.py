import pytest
from ..app import App
import json
from project.db.tables import device, history


@pytest.fixture
def app():
    app = App(test_run=True)
    app.initialize()
    sanic = app.web.sanic

    yield sanic


@pytest.fixture
def test_cli(loop, app, sanic_client):
    return loop.run_until_complete(sanic_client(app))


@pytest.fixture
async def test_device(test_cli):
    device_query = device.insert().values(
        device='1-wire',
        address='23-4434343434',
        topic='device/test_1_wire',
        port='1-Wire',
        interval=4000,
        history=60,
    )

    device_id = await test_cli.app.db.execute(device_query)

    yield device_id

    query = device.delete().where(device.c.id == int(device_id))
    await test_cli.app.db.execute(query)


@pytest.fixture
async def auth_headers(test_cli):
    data = {'username': "admin", "password": "admin"}
    resp = await test_cli.post('/auth', data=json.dumps(data))
    resp_json = await resp.json()
    headers = {'Authorization': f"Bearer {resp_json['access_token']}"}

    yield headers

"""
TESTS
"""


async def test_get_unauth_device_history(test_cli):
    """
    GET devices history
    must error
    """
    data = {"device":1,"channel":"datetime","dates":["2021-01-04","2021-01-05"]}

    resp = await test_cli.post('/api/devices/values', data=json.dumps(data))
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'


async def test_get_fail_device_history(test_cli, auth_headers):
    """
    GET devices history
    must error
    """
    data = {"device":1,"channel":"datetime","dates":["2021-01-04","2021-01-05"]}

    resp = await test_cli.post('/api/devices/values', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 400
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert resp_json['error'] == 'DeviceNotFound'


async def test_get_device_history(test_cli, test_device, auth_headers):
    """
    GET devices history
    must error
    """
    data = {"device":test_device,"channel":"temperature","dates":["2021-01-04","2021-01-05"]}

    resp = await test_cli.post('/api/devices/values', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert type(resp_json) == dict
    assert 'values' in resp_json
    assert 'labels' in resp_json


async def test_get_unauth_device_history_csv(test_cli):
    """
    GET devices history csv
    must error
    """
    data = {"device": 1, "channel": "datetime", "dates": ["2021-01-04", "2021-01-05"]}
    resp = await test_cli.post('/api/devices/values/create_csv', data=json.dumps(data))
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'


async def test_get_fail_device_history_csv(test_cli,auth_headers):
    """
    GET devices history csv
    must error
    """
    data = {"device": 1, "channel": "datetime", "dates": ["2021-01-04", "2021-01-05"]}
    resp = await test_cli.post('/api/devices/values/create_csv', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 400
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert resp_json['error'] == 'DeviceNotFound'


async def test_get_device_history_csv(test_cli, test_device, auth_headers):
    """
    GET devices history csv
    must error
    """
    data = {"device": test_device, "channel": "temperature", "dates": ["2021-01-04", "2021-01-05"]}
    resp = await test_cli.post('/api/devices/values/create_csv', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert type(resp_json) == str