import os
from yaml import safe_load
import pytest
import json
from ..app import App


@pytest.fixture
def app():
    app = App(test_run=True)
    app.initialize()
    sanic = app.web.sanic

    yield sanic


@pytest.fixture
def test_cli(loop, app, sanic_client):
    return loop.run_until_complete(sanic_client(app))


@pytest.fixture
async def auth_headers(test_cli):
    data = {'username': "admin", "password": "admin"}
    resp = await test_cli.post('/auth', data=json.dumps(data))
    resp_json = await resp.json()
    headers = {'Authorization': f"Bearer {resp_json['access_token']}"}

    yield headers

"""
TESTS
"""


async def test_unauth_get_serial(test_cli):
    """
    GET serial
    must be empty
    """
    resp = await test_cli.get('/api/serial')
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'

async def test_get_serial(test_cli, auth_headers):
    """
    GET serial
    must be empty
    """
    resp = await test_cli.get('/api/serial', headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'

async def test_unauth_post_serial(test_cli):
    """
    POST serial
    """
    data = {
        "serials": {
            "rs232_1": {
                "baud": 2400,
                "databit": 8,
                "device": "ttyS2",
                "parity": "None",
                "stopbit": 1,
                "rs485_enable": False
            },
            "rs232_2": {
                "baud": 2400,
                "databit": 8,
                "device": "ttyS3",
                "parity": "None",
                "stopbit": 1,
                "rs485_enable": False
            },
            "rs485_1": {
                "baud": 19200,
                "databit": 8,
                "device": "ttyS0",
                "parity": "None",
                "stopbit": 1,
                "rs485_enable": True
            },
            "rs485_2": {
                "baud": 115200,
                "databit": 8,
                "device": "ttyS1",
                "parity": "None",
                "stopbit": 1,
                "rs485_enable": True
            }
        }
    }
    resp = await test_cli.post('/api/serial', data=json.dumps(data))
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'

async def test_post_serial(test_cli, auth_headers):
    """
    POST serial
    """
    data = {
        "serials": {
            "rs232_1": {
                "baud": 2400,
                "databit": 8,
                "device": "ttyS2",
                "parity": "None",
                "stopbit": 1,
                "rs485_enable": False
            },
            "rs232_2": {
                "baud": 2400,
                "databit": 8,
                "device": "ttyS3",
                "parity": "None",
                "stopbit": 1,
                "rs485_enable": False
            },
            "rs485_1": {
                "baud": 19200,
                "databit": 8,
                "device": "ttyS0",
                "parity": "None",
                "stopbit": 1,
                "rs485_enable": True
            },
            "rs485_2": {
                "baud": 115200,
                "databit": 8,
                "device": "ttyS1",
                "parity": "None",
                "stopbit": 1,
                "rs485_enable": True
            }
        }
    }
    resp = await test_cli.post('/api/serial', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert resp_json == True


async def test_write_to_file_serial(test_cli, auth_headers):
    """
    POST serial
    """
    data = {
        "serials": {
            "rs232_1": {
                "baud": 2400,
                "databit": 8,
                "device": "ttyS2",
                "parity": "None",
                "stopbit": 1,
                "rs485_enable": False
            },
            "rs232_2": {
                "baud": 2400,
                "databit": 8,
                "device": "ttyS3",
                "parity": "None",
                "stopbit": 1,
                "rs485_enable": False
            },
            "rs485_1": {
                "baud": 19200,
                "databit": 8,
                "device": "ttyS0",
                "parity": "None",
                "stopbit": 1,
                "rs485_enable": True
            },
            "rs485_2": {
                "baud": 115200,
                "databit": 8,
                "device": "ttyS1",
                "parity": "None",
                "stopbit": 1,
                "rs485_enable": True
            }
        }
    }
    resp = await test_cli.post('/api/serial', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 200
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert resp_json == True

    with open(
            os.path.join(os.path.abspath(
                os.path.join(
                    os.path.dirname(__file__),
                    '..'
                )
            ), '../device_configs/serial.yml'),
            'r',
            encoding='utf-8'
    ) as f:
        serial_config = safe_load(f.read())
        f.close()
    del serial_config['serial']['config']
    assert serial_config['serial'] == data['serials']

async def test_post_serial_400_error(test_cli, auth_headers):
    """
    POST serial
    """
    data = {
        "serials": {
            "rs232_1": {
                "baud": '2400',
                "databit": 8,
                "device": "ttyS2",
                "parity": "None",
                "stopbit": 1
            }
        }
    }
    resp = await test_cli.post('/api/serial', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 400
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert "ValidationError" == resp_json['error']

async def test_post_serial_400_error2(test_cli, auth_headers):
    """
    POST serial
    """
    data = {
        "serials": {
            "rs232_1": {
                "baud": '2400',
                "databit": 8,
                "device": "ttyS2",
                "parity": "None",
                "stopbit": 1,
                "rs485_enable": True
            },
            "rs232_2": {
                "baud": 2400,
                "databit": 8,
                "device": "ttyS3",
                "parity": "None",
                "stopbit": 1,
                "rs485_enable": True
            },
            "rs485_1": {
                "baud": 19200,
                "databit": 8,
                "device": "ttyS0",
                "parity": "None",
                "stopbit": 1,
                "rs485_enable": True
            },
            "rs485_2": {
                "baud": 115200,
                "databit": 8,
                "device": "ttyS1",
                "parity": "None",
                "stopbit": 1,
                "rs485_enable": True
            }
        }
    }
    resp = await test_cli.post('/api/serial', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 400
    assert resp.content_type == 'application/json'
    resp_json = await resp.json()
    assert "'2400' is not of type 'integer'" == resp_json['data']['message']
    assert "ValidationError" == resp_json['error']
