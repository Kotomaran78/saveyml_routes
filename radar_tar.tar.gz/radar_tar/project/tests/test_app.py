import os
import pytest
from ..app import App
from sqlalchemy import create_engine
from sqlalchemy_utils import database_exists, create_database, drop_database
from yaml import safe_load, safe_dump
import json

@pytest.fixture(scope="package", autouse=True)
def app():
    main_app = App(test_run=True)
    main_app.initialize()
    main_app.web._init_mqobserver()

    yield main_app

@pytest.fixture
def sanic(app):
    sanic = app.web.sanic

    yield sanic


@pytest.fixture
def test_cli(loop, sanic, sanic_client):
    return loop.run_until_complete(sanic_client(sanic))


@pytest.fixture(scope="package", autouse=True)
def database():
    with open(os.path.join(os.path.dirname(__file__), 'config.test.yml'), 'r', encoding='utf-8') as c:
        test_config = safe_load(c.read())
    engine = create_engine(test_config['web']['sanic']['DB_URL'])
    if not database_exists(engine.url):  # Checks for the first time
        create_database(engine.url)  # Create new DB
        os.chdir(os.path.join(os.path.dirname(__file__), '../..'))
        os.system('alembic --name test upgrade head')

    yield

    drop_database(engine.url)


@pytest.fixture
async def auth_headers(test_cli):
    data = {'username': "admin", "password": "admin"}
    resp = await test_cli.post('/auth', data=json.dumps(data))
    resp_json = await resp.json()
    headers = {'Authorization': f"Bearer {resp_json['access_token']}"}

    yield headers

"""
TESTS
"""

async def test_get_index(test_cli):
    """
    GET index page
    """
    resp = await test_cli.get('/')
    assert resp.status == 200
    assert resp.headers['content-type'] == 'text/html'

async def test_get_unauth_status(test_cli):
    """
    GET server status
    """
    resp = await test_cli.get('/api/status')
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'

async def test_get_status(test_cli, auth_headers):
    """
    GET server status
    """
    resp = await test_cli.get('/api/status', headers=auth_headers)
    assert resp.status == 200
    resp_json = await resp.json()
    assert 'device_id' in resp_json
    assert 'time' in resp_json
    assert 'active_connection' in resp_json
    assert 'free_space' in resp_json
    assert 'total_space' in resp_json
    assert 'main_mqtt_server' in resp_json

async def test_post_unauth_reboot(test_cli):
    """
    POST server reboot
    """
    resp = await test_cli.post('/api/config/reboot')
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'

async def test_post_reboot(test_cli, auth_headers):
    """
    POST server reboot
    """
    resp = await test_cli.post('/api/config/reboot', headers=auth_headers)
    assert resp.status == 200
    resp_json = await resp.json()
    assert resp_json == True

async def test_unauth_reset(test_cli):
    """
    POST server reset
    """
    resp = await test_cli.post('/api/config/reset')
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'

async def test_reset(test_cli, auth_headers):
    """
    POST server reset
    """
    resp = await test_cli.post('/api/config/reset', headers=auth_headers)
    assert resp.status == 200
    resp_json = await resp.json()
    assert resp_json == True

async def test_unauth_update(test_cli):
    """
    POST server update
    """
    resp = await test_cli.post('/api/config/update')
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'

async def test_update(test_cli, auth_headers):
    """
    POST server update
    """
    resp = await test_cli.post('/api/config/update', headers=auth_headers)
    assert resp.status == 200
    resp_json = await resp.json()
    assert resp_json == True

async def test_unauth_locale(test_cli):
    """
    GET server locale
    """
    resp = await test_cli.get('/api/config/locale')
    assert resp.status == 200
    resp_json = await resp.json()
    assert resp_json == 'en'

async def test_post_ru_locale(test_cli):
    """
    POST ru locale
    """
    data = {'locale': "ru"}
    resp = await test_cli.post('/api/config/locale', data=json.dumps(data))
    assert resp.status == 200
    resp_json = await resp.json()
    assert resp_json == True


async def test_post_en_locale(test_cli):
    """
    POST en locale
    """
    data = {'locale': "ru"}
    resp = await test_cli.post('/api/config/locale', data=json.dumps(data))
    assert resp.status == 200
    resp_json = await resp.json()
    assert resp_json == True

async def test_post_fail_fr_locale(test_cli):
    """
    POST fail fr locale
    """
    data = {'locale': "fr"}
    resp = await test_cli.post('/api/config/locale', data=json.dumps(data))
    assert resp.status == 400
    resp_json = await resp.json()
    assert resp_json['error'] == 'ValidationError'

async def test_unauth_mqtt(test_cli):
    """
    GET server mq settings
    """
    resp = await test_cli.get('/api/config/mqtt')
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'

async def test_mqtt(test_cli, auth_headers):
    """
    GET server mq settings
    """
    resp = await test_cli.get('/api/config/mqtt', headers=auth_headers)
    assert resp.status == 200
    resp_json = await resp.json()
    assert resp_json == \
           {
               'backup':
                   {
                        'gateway': '127.0.0.1',
                        'gwport': 1003,
                        'host': '127.0.0.1',
                        'port': 1883,
                        'keepalive': 10,
                        'password': 'admin',
                        'protocol': 'mqtt/tcp',
                        'qos': 1,
                        'reconnect': 1000,
                        'timeout': 30000,
                        'username': 'admin'
                    },
               'main':
                   {
                       'gateway': '127.0.0.1',
                       'gwport': 1003,
                       'host': '127.0.0.1',
                       'port': 1883,
                       'keepalive': 10,
                       'password': 'admin',
                       'protocol': 'mqtt/tcp',
                       'qos': 1,
                       'reconnect': 1000,
                       'timeout': 30000,
                       'username': 'admin'
                   }
           }


async def test_unauth_post_mqtt(test_cli):
    """
    POST mqtt
    """
    data = {"main":{"protocol":"mqtt/tcp","host":"127.0.0.1:1883","port":1883,"username":"admin","password":"admin","keepalive":10,"timeout":30000,"reconnect":1000,"qos":1,"gateway":"23.22.133.33","gwport":1003},"backup":{"protocol":"mqtt/tcp","host":"127.0.0.1:1883","port":1883,"username":"admin","password":"admin","keepalive":10,"timeout":30000,"reconnect":1000,"qos":1,"gateway":"23.22.133.33","gwport":1003}}

    resp = await test_cli.post('/api/config/mqtt/main', data=json.dumps(data))
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'

async def test_post_mqtt_main(test_cli, auth_headers):
    """
    POST mqtt
    """
    data = {"protocol":"mqtt/tcp","host":"127.0.0.1:1883","port":1883,"username":"admin","password":"admin","keepalive":10,"timeout":30000,"reconnect":1000,"qos":1,"gateway":"23.22.133.33","gwport":1003}

    resp = await test_cli.post('/api/config/mqtt/main', data=data, headers=auth_headers)
    assert resp.status == 200
    resp_json = await resp.json()
    assert resp_json == True

async def test_post_mqtt_backup(test_cli, auth_headers):
    """
    POST mqtt
    """
    data = {"protocol":"mqtt/tcp","host":"127.0.0.1:1883","port":1883,"username":"admin","password":"admin","keepalive":10,"timeout":30000,"reconnect":1000,"qos":1,"gateway":"23.22.133.33","gwport":1003}

    resp = await test_cli.post('/api/config/mqtt/backup', data=data, headers=auth_headers)
    assert resp.status == 200
    resp_json = await resp.json()
    assert resp_json == True

async def test_fail_post_mqtt(test_cli, auth_headers):
    """
    POST mqtt
    """
    data = {"port": 1883, "username": "admin",
                     "password": "admin", "keepalive": 10, "timeout": 30000, "reconnect": 1000, "qos": 1,
                     "gateway": "23.22.133.33", "gwport": 1003}

    resp = await test_cli.post('/api/config/mqtt/main', data=data, headers=auth_headers)
    assert resp.status == 400
    resp_json = await resp.json()
    assert resp_json['error'] == 'ValidationError'

async def test_unauth_network(test_cli):
    """
    GET network
    """
    resp = await test_cli.get('/api/config/network')
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'

async def test_network(test_cli, auth_headers):
    """
    GET network
    """
    resp = await test_cli.get('/api/config/network', headers=auth_headers)
    assert resp.status == 200

async def test_unauth_post_network(test_cli):
    """
    POST network
    """
    data = {
        "lan1": {
            "mac": "E8:6A:64:1B:1A:DD",
            "hostname": "MF337223329213",
            "dhcp": False,
            "address": "192.168.0.20",
            "netmask": "255.255.255.0",
            "gateway": "192.168.0.1",
            "firstDns": "192.168.0.254",
            "secondDns": "192.168.0.254",
            "dev": "enp0s31f6"
        },
        "lan2": {
            "mac": "E8:6A:64:1B:1A:DD",
            "hostname": "MF337223329213",
            "dhcp": False,
            "address": "192.168.0.20",
            "netmask": "255.255.255.0",
            "gateway": "192.168.0.1",
            "firstDns": "192.168.0.254",
            "secondDns": "192.168.0.254",
            "dev": "enp0s31f6"
        },
        "cellular": {
            "pin": "",
            "plmn": 25002,
            "apn": "internet",
            "username": "",
            "password": ""
        },
        "priority": [
            "lan2",
            "lan1",
            "mobile"
        ]
    }

    resp = await test_cli.post('/api/config/network', data=json.dumps(data))
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'


async def test_post_dhcp_network(test_cli, auth_headers):
    """
    POST network
    """
    data = {
        "lan1": {
            "dev": "enp0s31f6",
            "hostname": "daq_test",
            "dhcp": True,
            "address": "",
            "netmask": "",
            "gateway": "",
            "dns": [
            ],
            "mac": "E8:6A:64:1B:1A:DD",
            "metric": 400,
            "active": True
        },
        "lan2": {
            "dev": "wlp3s0",
            "hostname": "daq_test",
            "dhcp": True,
            "address": "",
            "netmask": "",
            "gateway": "",
            "dns": [
            ],
            "mac": "B4:69:21:5D:30:E5",
            "metric": 300,
            "active": True
        },
        "mobile": {
            "dev": None,
            "active": False
        },
        "active_connection": "lan2",
        "priority": [
            "lan1",
            "lan2",
            "mobile"
        ]
    }

    resp = await test_cli.post('/api/config/network', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 200
    resp_json = await resp.json()
    assert resp_json == True

async def test_post_static_network(test_cli, auth_headers):
    """
    POST network
    """
    data = {
        "lan1": {
            "dev": "enp0s31f6",
            "hostname": "daq_test",
            "dhcp": False,
            "address": "192.168.6.9",
            "netmask": "255.255.255.0",
            "gateway": "192.168.6.1",
            "dns": [
                "192.168.6.1"
            ],
            "mac": "E8:6A:64:1B:1A:DD",
            "metric": 400,
            "active": True
        },
        "lan2": {
            "dev": "wlp3s0",
            "hostname": "daq_test",
            "dhcp": False,
            "address": "192.168.6.10",
            "netmask": "255.255.255.0",
            "gateway": "192.168.6.1",
            "dns": [
                "192.168.6.1"
            ],
            "mac": "B4:69:21:5D:30:E5",
            "metric": 300,
            "active": True
        },
        "mobile": {
            "dev": None,
            "active": False
        },
        "active_connection": "lan2",
        "priority": [
            "lan1",
            "lan2",
            "mobile"
        ]
    }

    resp = await test_cli.post('/api/config/network', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 200
    resp_json = await resp.json()
    assert resp_json == True


async def test_fail_post_network(test_cli, auth_headers):
    """
    POST fail network
    """
    data = {
        "lan1": {
            "mac": "E8:6A:64:1B:1A:DD",
            "hostname": "MF337223329213",
            "dhcp": False,
            "address": "192.168.0.20",
            "netmask": "255.255.255.0",
            "gateway": "192.168.0.1",
            "firstDns": "192.168.0.254",
            "secondDns": "192.168.0.254",
            "dev": "enp0s31f6"
        },
        "priority": [
            "lan2",
            "lan1",
            "mobile"
        ]
    }

    resp = await test_cli.post('/api/config/network', data=json.dumps(data), headers=auth_headers)
    assert resp.status == 400
    resp_json = await resp.json()
    assert resp_json['error'] == 'ValidationError'

async def test_unauth_time(test_cli):
    """
    GET network
    """
    resp = await test_cli.get('/api/config/time')
    assert resp.status == 401
    resp_json = await resp.json()
    assert resp_json['error'] == 'Unauthorized'
    assert resp_json['message'] == 'Authorization header not present.'

async def test_time(test_cli, auth_headers):
    """
    GET network
    """
    resp = await test_cli.get('/api/config/time', headers=auth_headers)
    assert resp.status == 200
    resp_json = await resp.json()
    assert 'time' in resp_json
    assert 'ntps' in resp_json
    assert isinstance(resp_json['time'], str)
    assert isinstance(resp_json['ntps'], list)