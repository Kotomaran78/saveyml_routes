from os import path
from yaml import safe_load


def load_schema(app, schema_file):
    with open(
            path.join(app.root, 'schema/' + schema_file),
            'r',
            encoding='utf-8'
    ) as f:
        serial_schema = safe_load(f.read())
        f.close()
    return serial_schema
