from os import path, fsync
from yaml import safe_load, safe_dump


def config(app, test_run):
    # config root
    root = app.config_root

    # default config
    conf = {
        "web": {
            "host": "0.0.0.0",
            "port": 8000,
            "workers": 1,
            "debug": False,
            "sanic": {
                "REQUEST_TIMEOUT": 60,
                "RESPONSE_TIMEOUT": 1*60*60,
                "REQUEST_MAX_SIZE": 150000000,
                "KEEP_ALIVE": True,
                "KEEP_ALIVE_TIMEOUT": 10*60,
                "DB_URL": "postgresql://default:secret@postgres/newsanic"
            }
        },
        "ntp_config": "config/ntp.conf",
        "mq": {
            "host": "localhost",
            "username": "admin",
            "password": "admin",
            "topic": "device",
            "port": 5672
        }
    }

    # yaml file config
    if test_run:
        with open(
                path.join(root, '../tests/config.test.yml'),
                'r',
                encoding='utf-8'
        ) as f:
            loaded_conf = safe_load(f.read())
            conf = {
                **conf,
                **loaded_conf
            }
            f.close()
    else:
        config_file = 'config.yml'
        if path.exists(path.join(root, 'config.local.yml')):
            config_file = 'config.local.yml'
        with open(
                path.join(root, config_file),
                'r',
                encoding='utf-8'
        ) as f:
            loaded_conf = safe_load(f.read())
            conf = {
                **conf,
                **loaded_conf
            }
            f.close()

    return conf


def saveConfig(app, newconfig, test_run=False):
    config_file = 'config.yml'
    root = app.config_root

    if path.exists(path.join(root, 'config.local.yml')):
        config_file = 'config.local.yml'
    if test_run:
        config_file = 'config.test.yml'
        root = path.join(root, '../tests')

    with open(path.join(root, config_file), 'w', encoding='utf-8') as cf:
        cf.write(safe_dump(newconfig))
        cf.flush()
        fsync(cf.fileno())
        cf.close()
    return True
