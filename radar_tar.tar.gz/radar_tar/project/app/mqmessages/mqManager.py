import asyncio
import pika
from json import loads, dumps


def receive(app):
    credentials = pika.PlainCredentials(app.config['mq']['username'], app.config['mq']['password'])
    parameters = pika.ConnectionParameters(host=app.config['mq']['host'], credentials=credentials)
    connection = pika.BlockingConnection(parameters)
    channel = connection.channel()
    channel.queue_declare(queue='status', durable=True)
    method_frame, header_frame, body = channel.basic_get(queue='status')
    if method_frame is None or method_frame.NAME == 'Basic.GetEmpty':
        connection.close()
        return None
    else:
        channel.basic_ack(delivery_tag=method_frame.delivery_tag)
        connection.close()
        return loads(body.decode("utf-8"))

SLEEP_DURATION = 5e-3

@asyncio.coroutine
async def checkMessage(app, mq_checker):
    msg = receive(app)
    if msg is not None:
        await mq_checker.set_status(msg)
    # await asyncio.sleep(0.1)
    # await asyncio.sleep(0)
    await asyncio.sleep(SLEEP_DURATION)


@asyncio.coroutine
def getmqmessages(app, mq_checker):
    while True:
        yield from checkMessage(app, mq_checker)
