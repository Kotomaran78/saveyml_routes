
class MqExchanger:
    def __init__(self, app):
        self._app = app

    @property
    def db(self):
        return self._app.web.sanic.db
