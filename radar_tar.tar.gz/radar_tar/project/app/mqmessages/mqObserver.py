import abc
from datetime import datetime, timedelta

import jsonschema
from jsonschema import validate

from project.db import history
from project.schema import load_schema
from project.db import device, history


class MqChecker:
    """
    Know its observers. Any number of Observer objects may observe a
    subject.
    Send a notification to its observers when its state changes.
    """

    def __init__(self, app, exchanger):
        self._app = app
        self.exchanger = exchanger
        self._observers = set()
        self._status = None

    @property
    def app(self):
        return self._app

    def attach(self, observer):
        observer._subject = self
        self._observers.add(observer)

    def detach(self, observer):
        observer._subject = None
        self._observers.discard(observer)

    async def _notify(self):
        for observer in self._observers:
            await observer.update(self._status)

    async def set_status(self, arg):
        self.status = arg
        await self._notify()

    @property
    def status(self):
        return self._status

    @status.setter
    def status(self, arg):
        self._status = arg


class Observer(metaclass=abc.ABCMeta):
    """
    Define an updating interfaces for objects that should be notified of
    changes in a subject.
    """

    def __init__(self):

        self._subject = None
        self._observer_state = None

    @abc.abstractmethod
    def update(self, arg):
        pass


class MqObserver(Observer):
    """
    Implement the Observer updating interfaces to keep its state
    consistent with the subject's.
    Store state that should stay consistent with the subject's.
    """

    def __init__(self, app, exchanger):
        super().__init__()
        self._app = app
        self.ee = app.event_emitter
        self.service = app.service
        self.exchanger = exchanger

    async def update(self, arg):
        message = None

        message_schema = load_schema(self._app, 'mqMessage.schema.json')

        for key in arg.keys():
            if '@' not in key:
                continue
            if 'gpio' in key:
                self.ee.emit('mqtt:gpio', arg)
                self.ee.emit('web:gpio', arg)
                continue
            if 'serial' in key:
                continue

            date = datetime.now()
            if 'timestamp' in arg:
                date = datetime.fromtimestamp(arg['timestamp']).isoformat()

            message = {
                "device": key,
                "value": arg[key],
                "read_at": date
            }

            try:
                validate(message, message_schema)
            except jsonschema.exceptions.ValidationError as err:
                print(err)
                return

        try:
            await self.exchanger.db.connect()
        except Exception as e:
            pass
        if message is not None:
            device_id = message['device'].split('@')

            db_device_query = device.select().where(device.c.id == int(device_id[1]))
            try:
                db_device = await self.exchanger.db.fetch_one(db_device_query)
            except:
                return
            if db_device is None:
                return
            message['read_at'] = datetime.fromisoformat(message['read_at'])
            self.ee.emit('mqtt:msg', db_device, message)

            find_last = history.select().where(history.c.device == message['device']).order_by(history.c.read_at.desc())
            try:
                last_history_msg = await self.exchanger.db.fetch_one(find_last)
            except:
                return

            if last_history_msg is None:
                insertQuery = history.insert().values(
                    message
                )
                try:
                    await self.exchanger.db.execute(insertQuery)
                except Exception as e:
                    print(e)
                    pass
                return

            last_history_msg_dict = dict(last_history_msg.items())

            db_device = dict(db_device.items())

            if (message['read_at'].timestamp() - last_history_msg_dict['read_at'].timestamp()) >= db_device['history'] * 60:
                insertQuery = history.insert().values(
                    message
                )
                try:
                    await self.exchanger.db.execute(insertQuery)
                    self.ee.emit("web:device", message)
                except Exception as e:
                    print(e)
                    pass

            date = datetime.now().timestamp() - (datetime.now() - timedelta(days=45)).timestamp()

            deleteQuery = history.delete().where(
                history.c.device == message['device']
            ).where(
                history.c.read_at < datetime.fromtimestamp(date)
            )

            await self.exchanger.db.execute(deleteQuery)