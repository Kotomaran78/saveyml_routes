from pyee import AsyncIOEventEmitter
from .events import load_events


def event_emitter(app):

    ee = AsyncIOEventEmitter(loop=app.loop)
    load_events(app, ee)

    return ee

