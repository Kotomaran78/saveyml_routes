from os import getenv, system
from datetime import datetime
from json import dumps
import asyncio


def load_events(app, ee):
    @ee.on('sys:start')
    async def sys_start_handler():

        try:
            print('system started')
            await app.web.sanic.db.connect()
        except:
            pass

    @ee.on('sys:stop')
    async def sys_stop_handler():
        try:
            print('system stopping')
            await app.web.sanic.db.disconnect()
        except:
            pass

    @ee.on('route:req')
    def handler():
        print('new request')

    @ee.on('trace:hop')
    async def handler(hop):
        # send to all ws client hop info with {id:number, address:addr, hostname:host}
        await app.web.send_all_sockets(dumps({
            'action': 'newHop',
            'timestamp': datetime.now().isoformat(),
            'hop': hop
        }))

    @ee.on('serial:config')
    async def handler(cfg):
        await app.service.serialService.config_update(cfg)

    @ee.on('serial:update')
    async def handler(interface, cfg):
        await app.service.mqmessage.update_serial_cfg(interface, cfg)

    @ee.on('relay:update')
    async def handler(gpo_name, value):
        await app.service.mqmessage.set_relay_status(gpo_name, value)

    @ee.on('mqtt:gpio')
    async def handler(msg):
        await app.mqtt.send_mqtt_gpio_msg(msg)

    @ee.on('web:gpio')
    async def handler(msg):
        for gpio in msg['gpio@gpio']:
            if 'o' in gpio:
                await app.web.send_all_sockets(dumps({
                    'action': 'update_relay',
                    'timestamp': datetime.now().isoformat(),
                    'relay': {'relay': gpio, 'value': msg['gpio@gpio'][gpio]}
                }))
            if 'i' in gpio:
                await app.web.send_all_sockets(dumps({
                    'action': 'update_discrete',
                    'timestamp': datetime.now().isoformat(),
                    'discrete': {'discrete': gpio, 'value': msg['gpio@gpio'][gpio]}
                }))

    @ee.on("web:device")
    async def handler(msg):
        msg['read_at'] = msg['read_at'].timestamp()
        await app.web.send_all_sockets(dumps({
            'action': 'device_point',
            'timestamp': datetime.now().isoformat(),
            'message': msg
        }))

    @ee.on('system:reboot')
    async def handler():
        await asyncio.sleep(5)
        print('reboot')
        if getenv("ENV") == 'production':
            system('reboot')

    @ee.on('mqtt:msg')
    async def handler(db_device, message):
        await app.mqtt.send_mqtt_msg(db_device, message)

    @ee.on('mqtt:disconnect')
    async def handler():
        await app.mqtt.disconnect()
