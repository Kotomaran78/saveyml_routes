import argparse

from project.app import App

__version__ = '0.2.8'

pid_file = '/var/run/daq.pid'


def get_pid():
    try:
        with open(pid_file, 'r') as pf:

            pid = int(pf.read().strip())
    except IOError:
        pid = None

    return pid


def main():
    parser = argparse.ArgumentParser(
        description="cli command launcher"
    )

    parser.add_argument(
        'command',
        nargs='+',
        default='console',
        help='main command: start, stop, console - for starting/stopping daemon or running in console mode'
    )

    args = parser.parse_args()
    params = vars(args)
    params['pidfile'] = pid_file

    app = App()
    if args.command[0] == 'console':
        print(f"DAQ version {__version__} \t Let's go!")
        app.run_console()
    elif KeyboardInterrupt:
        app.stop_console()
    else:
        print('Wrong command argument: choose from ("start", "stop", "console")')
