import sys
from asyncio import get_event_loop
from datetime import datetime
from os import path, system, getenv,mkdir

from yaml import safe_load

from project.app.eventemitter import event_emitter
from project.app.mqtt import MqttClient
from project.config import config
from project.config import saveConfig
from project.db import DB
from project.services import Services
from project.web import Web
from project.midlewares import setup_version


class App:
    def __init__(self, test_run=False) -> None:
        self.version = '0.2.8'
        self.test_run = test_run
        # app root path
        self.root = self.__detect_app_root()
        self.config_root = self.__detect_config_root()
        self.config = config(self, test_run)
        self.public_root = self.__detect_public_root()
        self.device_root = self.__detect_device_config_root()
        self.web = None
        self.loop = None
        self.service = None
        self.db = None
        self.event_emitter = event_emitter(self)
        self.mqtt = MqttClient(self)
        self.registers206 = None
        self.registers236 = None
        self.registersOneWire = None
        self.registersGanjubus = None
        self.cert_folder = path.join(self.root, 'certs')
        self.history_folder = path.join(self.root, 'history')
        # self._logger = init_logging(self)

    # @property
    # def log(self):
    #     return self._logger

    def get_time(self):
        return datetime.now().strftime("%d/%m/%Y %H:%M:%S")

    def detect_config_file(self, config_path):
        if not path.isfile(config_path):
            return path.join(self.root, config_path)
        return config_path

    def __detect_app_root(self):
        if getattr(sys, 'frozen', False):
            return path.dirname(sys.executable)
        elif __file__:
            return path.abspath(
                path.join(
                    path.dirname(__file__),
                    '..'
                )
            )

    def __detect_config_root(self):
        _config_roots = []

        _config_roots.append(path.join(self.root, 'config'))
        for dpath in _config_roots:
            if path.exists(dpath):
                return dpath

        return None

    def __detect_public_root(self):
        _config_roots = []

        # if self.config['web']['public']:
        #     _config_roots.append(self.config['web']['public'])

        _config_roots.append(path.join(self.root, 'public'))
        for dpath in _config_roots:
            if path.exists(dpath):
                return dpath

        return None

    def __detect_device_config_root(self):
        if self.test_run:
            return path.join(path.abspath(
                path.join(
                    path.dirname(__file__),
                    '../..'
                )
            ), 'device_configs')
        if getenv('ENV') == 'development':
            return getenv('DEVICE_CONFIGS_PATH')
        return '/etc/daq'

    def _load_registers236(self):
        with open(
                path.join(self.device_root, 'registry/mercury_236.yml'),
                'r',
                encoding='utf-8'
        ) as f:
            loaded_conf = safe_load(f.read())
            f.close()
        return loaded_conf

    def _load_registers206(self):
        with open(
                path.join(self.device_root, 'registry/mercury_206.yml'),
                'r',
                encoding='utf-8'
        ) as f:
            loaded_conf = safe_load(f.read())
            f.close()
        return loaded_conf

    def _load_registersOneWire(self):
        with open(
                path.join(self.device_root, 'registry/ds18b20.yml'),
                'r',
                encoding='utf-8'
        ) as f:
            loaded_conf = safe_load(f.read())
            f.close()
        return loaded_conf

    def _load_registersGanjubus(self):
        with open(
                path.join(self.device_root, 'registry/ganjubus.yml'),
                'r',
                encoding='utf-8'
        ) as f:
            loaded_conf = safe_load(f.read())
            f.close()
        return loaded_conf

    def updateConfig(self):
        if not self.test_run:
            saveConfig(self, self.config)
            self.config = config(self, self.test_run)
            system('sync')

    def initialize(self, ):
        self.loop = get_event_loop()
        if not path.exists(self.cert_folder):
            mkdir(self.cert_folder)
        if not path.exists(self.history_folder):
            mkdir(self.history_folder)

        # Load services
        self.service = Services(self)

        # Load main code
        self.web = Web(self)

        setup_version(self)

        # Load db
        self.db = DB(self).setup_database()

        # self.registers206 = self._load_registers206()
        # self.registers236 = self._load_registers236()
        # self.registersOneWire = self._load_registersOneWire()
        self.registersGanjubus = self._load_registersGanjubus()
        # self.service.serialService.init_config()

    def run_console(self):
        self.initialize()

        self.web.start()
        self.event_emitter.emit('sys:start')
        try:
            self.loop.run_forever()
        except:
            self.loop.stop()

    def stop_console(self):
        self.loop.stop()
