from os import path
from datetime import datetime
from json import loads, dumps
import ssl
import asyncio

import aiomqtt


class MqttClient:
    def __init__(self, app):
        self._app = app
        self.id = self._app.config['device']['id']
        self._main_server = None
        self._backup_server = None

    @property
    def config(self):
        return self._app.config['mqtt']

    async def _connect(self):
        for server in self.config:
            if self.config[server]['protocol'] is None:
                continue
            if self.config[server]['host'] is None or self.config[server]['host'] == '':
                continue

            mqClient, default_port = self._server_type_select(server)
            mqClient.loop_start()
            port = default_port
            if self.config[server]['port'] is not None:
                port = self.config[server]['port']

            if 'username' and 'password' in self.config[server]:
                if self.config[server]['username'] != '' and self.config[server]['password'] != '':
                    auth = {'username': self.config[server]['username'], 'password': self.config[server]['password']}
                    mqClient.username_pw_set(**auth)

            mqClient.reconnect_delay_set(120, 240)
            try:
                await mqClient.connect(self.config[server]['host'], port)
                if server == 'main':
                    self._main_server = mqClient
                else:
                    self._backup_server = mqClient
            except Exception as e:
                print(e)

    async def disconnect(self):
        if self._main_server is not None:
            disconnected = asyncio.Event(loop=self._app.loop)

            def on_disconnect(client, userdata, rc):
                disconnected.set()

            self._main_server.on_disconnect = on_disconnect

            self._main_server.disconnect()
            await disconnected.wait()
            await self._main_server.loop_stop()
            self._main_server = None

        if self._backup_server is not None:
            disconnected = asyncio.Event(loop=self._app.loop)

            def on_disconnect(client, userdata, rc):
                disconnected.set()

            self._backup_server.on_disconnect = on_disconnect

            self._backup_server.disconnect()
            await disconnected.wait()
            await self._backup_server.loop_stop()
            self._backup_server = None

    def _server_type_select(self, server):
        if self.config[server]['protocol'] == 'mqtt/tcp':
            return aiomqtt.Client(self._app.loop, clean_session=True), 1883

        if self.config[server]['protocol'] == 'mqtt/tls':
            client = aiomqtt.Client(self._app.loop, clean_session=True)
            tls = {
                'tls_version': ssl.PROTOCOL_TLSv1_2,
                'ca_certs': path.join(path.join(self._app.cert_folder, server), self.config['server']['ca'])
            }
            if self.config['server']['cert'] is not None:
                tls['certfile'] = path.join(path.join(self._app.cert_folder, server), self.config['server']['cert'])

            if self.config['server']['cert'] is not None:
                tls['keyfile'] = path.join(path.join(self._app.cert_folder, server), self.config['server']['key'])

            client.tls_set(**tls)
            return client, 8883

        if self.config[server]['protocol'] == 'ws':
            return aiomqtt.Client(self._app.loop, transport='websockets', clean_session=True), 8080

        if self.config[server]['protocol'] == 'wss':
            client = aiomqtt.Client(self._app.loop, transport='websockets', clean_session=True)
            tls = {
                'tls_version': ssl.PROTOCOL_TLSv1_2,
                'ca_certs': path.join(path.join(self._app.cert_folder, server), self.config['server']['ca'])
            }
            if self.config['server']['cert'] is not None:
                tls['certfile'] = path.join(path.join(self._app.cert_folder, server), self.config['server']['cert'])

            if self.config['server']['cert'] is not None:
                tls['keyfile'] = path.join(path.join(self._app.cert_folder, server), self.config['server']['key'])

            client.tls_set(**tls)
            return client, 8081

    async def _send_mqtt_msg(self, path, msg):
        if self._main_server is None:
            await self._connect()

        if self._main_server is not None:
            message_info = self._main_server.publish(path, dumps(msg), qos=self.config['main']['qos'])
            await message_info.wait_for_publish()

        if self._backup_server is not None:
            message_info = self._main_server.publish(path, dumps(msg), qos=self.config['backup']['qos'])
            await message_info.wait_for_publish()

    async def send_mqtt_msg(self, device, msg):
        # <device_id>/devices/<device_name>/<channel_name>
        # <device_id>/devices/<device_name>/<channel_name>/history
        # <device_id>/devices/relays/<relay_name>
        # <device_id>/devices/di/<di_name>
        # <device_id>/status

        device_name = msg['device'].split('@')[0]

        registers = self._app.registers206
        if 'mercury_236' in device_name:
            registers = self._app.registers236
        if 'ds18b20' in device_name:
            registers = self._app.registersOneWire
        if 'ganjubus' in device_name:
            registers = self._app.registersGanjubus

        topic = f"{self.id}/devices/{device['topic']}"
        for channel in msg['value']:
            path = topic + '/' + channel
            data = {
                'path': path,
                'ts': int(msg['read_at'].timestamp()),
                'value': msg['value'][channel],
                'units': registers[channel]['unit']
            }

            await self._send_mqtt_msg(path, data)

    async def send_mqtt_gpio_msg(self, msg):
        topic = f"{self.id}/devices"
        for gpio in msg['gpio@gpio'].keys():
            subpath = '/relays/' + gpio
            if 'i' in gpio:
                subpath = '/di/' + gpio

            data = {
                'path': topic + subpath,
                "ts": int(msg['timestamp']),
                "value": int(msg['gpio@gpio'][gpio])
            }
            await self._send_mqtt_msg(topic+subpath, data)
