from project.app.main import main
from dotenv import load_dotenv
import os.path


if __name__ == '__main__':
    if os.path.isfile('.env.local'):
        load_dotenv(dotenv_path='.env.local', verbose=True)
    else:
        load_dotenv(verbose=True)
    main()
