# import logging
import pika
from os import path, system
from yaml import safe_load
from datetime import datetime
import random
import argparse
import json
import time
parser = argparse.ArgumentParser(
        description="cli command launcher"
)

parser.add_argument(
    'device_id',
    nargs='+',
    default='console',
    help='main command: start, stop, console - for starting/stopping daemon or running in console mode'
)

args = parser.parse_args()
params = vars(args)

with open(
        path.join('/etc/daq/ds18b20.yml'),
        'r',
        encoding='utf-8'
) as f:
    loaded_conf = safe_load(f.read())
    f.close()

sleep_time = loaded_conf[int(args.device_id[0])]['config']['poll_interval'] / 1000

credentials = pika.PlainCredentials('admin', 'admin')
parameters = pika.ConnectionParameters('localhost', credentials=credentials)
connection = pika.BlockingConnection(parameters)
channel = connection.channel()

while True:
    value_format = '{:.4}'
    value = value_format.format(float(random.uniform(20.0, 40.0)))

    data = {
        'ds18b20@' + args.device_id[0]: {
            "temperature": value
        },
        'timestamp': int(datetime.now().timestamp())

    }

    print("Sending da18b20 message")
    channel.basic_publish(
        'device', 'status', json.dumps(data))
    time.sleep(sleep_time)

connection.close()
