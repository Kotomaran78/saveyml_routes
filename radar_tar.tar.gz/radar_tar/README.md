Install requirements libraries by run 
```sh 
pip3 install -r requirements.txt
```

install dhcpcd5 package ```apt install dhcpcd5```
remove all ethN interfaces from file `/etc/network/interfaces`

confirm settings in 
```.env``` file and ```config/config.yml``` file

confirm you have running postgres server and rabbitmq or other mq server

write settings to config/config.yml file

then write database params in file ```alembic.ini``` in production section

if you create NEW database, run command 
```shell script
alembic --name production upgrade head
```
the tables in the database will be created

for new install of rabbitmq-server run sh-script
```./init_mq.sh```

then start locale server run
```shell script
python3 run.py console
```

or make service for run it on system startup process


for run test install test library
```shell script
pip3 install -r requirements_test.txt
```

change username and password for db connection in file `project/tests/config.test.yml`

write database params in file ```alembic.ini``` in test section

and start test
```shell script
pytest --cov=project project/tests
```
Before all tests will be create DB for testing and in end of tests DB will be DROP