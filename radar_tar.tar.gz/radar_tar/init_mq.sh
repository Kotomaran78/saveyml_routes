#!/bin/bash

chmod +x rabbitmqadmin
./rabbitmqadmin declare exchange --vhost=/ name=device type=direct
# main status queue
./rabbitmqadmin declare queue --vhost=/ name=status durable=true
./rabbitmqadmin --vhost=/ declare binding source=device destination_type="queue" destination="status" routing_key="status"
# gpio queue
./rabbitmqadmin declare queue --vhost=/ name=gpio@gpio.command durable=true
./rabbitmqadmin --vhost=/ declare binding source=device destination_type="queue" destination="gpio@gpio.command" routing_key="gpio.gpio.command"
./rabbitmqadmin declare queue --vhost=/ name=gpio@gpio.info durable=true
./rabbitmqadmin --vhost=/ declare binding source=device destination_type="queue" destination="gpio@gpio.info" routing_key="gpio.gpio.info"
./rabbitmqadmin declare queue --vhost=/ name=gpio@gpio.info_reply durable=true
./rabbitmqadmin --vhost=/ declare binding source=device destination_type="queue" destination="gpio@gpio.info_reply" routing_key="gpio.gpio.info_reply"
# serial queue
./rabbitmqadmin declare queue --vhost=/ name=serial@serial.command durable=true
./rabbitmqadmin --vhost=/ declare binding source=device destination_type="queue" destination="serial@serial.command" routing_key="serial.serial.command"
./rabbitmqadmin declare queue --vhost=/ name=serial@serial.info durable=true
./rabbitmqadmin --vhost=/ declare binding source=device destination_type="queue" destination="serial@serial.info" routing_key="serial.serial.info"
./rabbitmqadmin declare queue --vhost=/ name=serial@serial.info_reply durable=true
./rabbitmqadmin --vhost=/ declare binding source=device destination_type="queue" destination="serial@serial.info_reply" routing_key="serial.serial.info_reply"